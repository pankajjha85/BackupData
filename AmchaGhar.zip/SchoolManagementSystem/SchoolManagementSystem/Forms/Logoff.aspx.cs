﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SchoolManagementSystem.BusinessLayer;
using System.Configuration;

namespace SchoolManagementSystem.Forms
{
    public partial class Logoff : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BLLogout BLLogoutObj = new BLLogout();
            BLLogoutObj.Logout();
            Response.Redirect(ConfigurationManager.AppSettings["login_page"]);
        }
    }
}