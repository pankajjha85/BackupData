﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using SchoolManagementSystem.SuperClass;

namespace SchoolManagementSystem.Forms
{
    public partial class Site1 : PMaster
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblUserName.Text = ConfigurationManager.AppSettings["hello_note"] + GetUserLoginID();
                WriteMenu();
                logout_link.HRef = ConfigurationManager.AppSettings["logoff_page"];
                logout_link.InnerText = "Logoff";
            }
        }

        void WriteMenu()
        {
            DataSet DSMenu = new DataSet();
            MenuItem MainMenu;
            MenuItem SubMenu;

            try
            {
                DSMenu = CreateMenu();
                if (DSMenu.Tables.Count >= 2)
                {
                    DataTable DTMainMenu = DSMenu.Tables[0];
                    DataTable DTSubMenu = DSMenu.Tables[1];

                    foreach (DataRow DRMainMenu in DTMainMenu.Rows)
                    {
                        MainMenu = new MenuItem(Convert.ToString(DRMainMenu["MainMenu"]), Convert.ToString(DRMainMenu["MainMenuURL"]), "", Convert.ToString(DRMainMenu["MainMenuURL"]));
                        foreach (DataRow DRSubMenu in DTSubMenu.Select("CatID = " + Convert.ToString(DRMainMenu["CatID"])))
                        {
                            SubMenu = new MenuItem(Convert.ToString(DRSubMenu["SubMenu"]), Convert.ToString(DRSubMenu["SubMenuURL"]), "", Convert.ToString(DRSubMenu["SubMenuURL"]));
                            MainMenu.ChildItems.Add(SubMenu);
                        }
                        Menu1.Items.Add(MainMenu);
                    }
                    DTMainMenu.Dispose();
                    DTSubMenu.Dispose();
                }
            }
            catch (Exception ex)
            {
                Response.Redirect(ConfigurationManager.AppSettings["error_page"]+ex.Message);
            }
        }
    }
}