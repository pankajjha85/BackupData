﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

using SchoolManagementSystem.SuperClass;

namespace SchoolManagementSystem.Forms
{
    public partial class Login : PLogin
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            string Result = ValidateLoginIDPwd(Login1.UserName, Login1.Password);
            if (Result == "Success")
            {
                e.Authenticated = true;
                Session["begin"] = DateTime.Now;
                Response.Redirect(ConfigurationManager.AppSettings["default_page"]);
            }
            else
            {
                Login1.FailureText = Result;
                e.Authenticated = false;
            }
        }

        protected void Login1_LoggingIn(object sender, LoginCancelEventArgs e)
        {
            
        }
    }
}