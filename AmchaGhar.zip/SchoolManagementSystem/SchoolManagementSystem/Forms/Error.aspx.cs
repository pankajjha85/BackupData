﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using SchoolManagementSystem.BusinessLayer;

namespace SchoolManagementSystem.Forms
{
    public partial class Error : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                error_image.Src = ConfigurationManager.AppSettings["error_image"];
                error_image.Width = Convert.ToInt32(ConfigurationManager.AppSettings["error_image_width"] == null ? "100" : ConfigurationManager.AppSettings["error_image_width"]);
                error_image.Height = Convert.ToInt32(ConfigurationManager.AppSettings["error_image_height"] == null ? "100" : ConfigurationManager.AppSettings["error_image_height"]);

                login_page_link.HRef = ConfigurationManager.AppSettings["login_page"];

                if (Request.QueryString["msg"] == null)
                {
                    lblMessage.Text = "Unrecognised Error.";
                }
                else
                {
                    lblMessage.Text = Request.QueryString["msg"];
                }
                BLLogout BLLogoutObj = new BLLogout();
                BLLogoutObj.Logout();
            }
        }
    }
}