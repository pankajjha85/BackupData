﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SchoolManagementSystem.Common;
using SchoolManagementSystem.BusinessLayer;
using System.Configuration;

namespace SchoolManagementSystem.Forms
{
    public partial class DataTransaction : PageBase
    {
        BLGetMasters BLGetMastersObj = new BLGetMasters();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                BindClass();
                BindDIV(Convert.ToInt32(ddlClass.SelectedValue), true);
                BindRollNumber(Convert.ToInt32(ddlClass.SelectedValue), Convert.ToInt32(ddlDiv.SelectedValue), true);
                BindStudents(Convert.ToInt32(ddlClass.SelectedValue), Convert.ToInt32(ddlDiv.SelectedValue), true);
                BindFeesTypes(Convert.ToInt32(ddlClass.SelectedValue), true);
            }
        }

        protected void ddlClass_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindDIV(Convert.ToInt32(ddlClass.SelectedValue), true);
            BindRollNumber(Convert.ToInt32(ddlClass.SelectedValue), Convert.ToInt32(ddlDiv.SelectedValue), true);
            BindStudents(Convert.ToInt32(ddlClass.SelectedValue), Convert.ToInt32(ddlDiv.SelectedValue), true);
            BindFeesTypes(Convert.ToInt32(ddlClass.SelectedValue), true);
        }

        protected void ddlDiv_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindRollNumber(Convert.ToInt32(ddlClass.SelectedValue), Convert.ToInt32(ddlDiv.SelectedValue), true);
            BindStudents(Convert.ToInt32(ddlClass.SelectedValue), Convert.ToInt32(ddlDiv.SelectedValue), true);
        }

        public void BindClass()
        {
            try
            {
                ddlClass.DataSource = BLGetMastersObj.GetClass();

                string DataTextField = BLGetMastersObj.Get_DDL_DataText_FieldName("class");
                string DataValueField = BLGetMastersObj.Get_DDL_DataValue_FieldName("class");

                if (DataTextField.Length == 0 || DataValueField.Length == 0)
                {
                    throw new Exception("Your Session is expired.");
                }

                ddlClass.DataTextField = DataTextField;
                ddlClass.DataValueField = DataValueField;

                ddlClass.DataBind();

                BindIfNoData(ddlClass);
            }
            catch (Exception ex)
            {
                Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ex.Message);
            }
        }

        public void BindDIV(int prmClassID, bool prmClearAllFirst)
        {
            try
            {
                if (prmClearAllFirst)
                {
                    ddlDiv.Items.Clear();
                }
                ddlDiv.DataSource = BLGetMastersObj.GetDiv(prmClassID);

                string DataTextField = BLGetMastersObj.Get_DDL_DataText_FieldName("div");
                string DataValueField = BLGetMastersObj.Get_DDL_DataValue_FieldName("div");

                if (DataTextField.Length == 0 || DataValueField.Length == 0)
                {
                    throw new Exception("Your Session is expired.");
                }

                ddlDiv.DataTextField = DataTextField;
                ddlDiv.DataValueField = DataValueField;
                ddlDiv.DataBind();

                BindIfNoData(ddlDiv);
            }
            catch (Exception ex)
            {
                Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ex.Message);
            }
        }

        public void BindRollNumber(int prmClassID, int prmDivID, bool prmClearAllFirst)
        {
            try
            {
                if (prmClearAllFirst)
                {
                    ddlRollNumber.Items.Clear();
                }
                ddlRollNumber.DataSource = BLGetMastersObj.GetStudents(prmClassID, prmDivID);

                string DataTextField = BLGetMastersObj.Get_DDL_DataText_FieldName("rollnumber");
                string DataValueField = BLGetMastersObj.Get_DDL_DataValue_FieldName("rollnumber");

                if (DataTextField.Length == 0 || DataValueField.Length == 0)
                {
                    throw new Exception("Your Session is expired.");
                }

                ddlRollNumber.DataTextField = DataTextField;
                ddlRollNumber.DataValueField = DataValueField;
                ddlRollNumber.DataBind();

                BindIfNoData(ddlRollNumber);
            }
            catch (Exception ex)
            {
                Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ex.Message);
            }
        }

        public void BindStudents(int prmClassID, int prmDivID, bool prmClearAllFirst)
        {
            try
            {
                if (prmClearAllFirst)
                {
                    ddlStudent.Items.Clear();
                }
                ddlStudent.DataSource = BLGetMastersObj.GetStudents(prmClassID, prmDivID);

                string DataTextField = BLGetMastersObj.Get_DDL_DataText_FieldName("student");
                string DataValueField = BLGetMastersObj.Get_DDL_DataValue_FieldName("student");

                if (DataTextField.Length == 0 || DataValueField.Length == 0)
                {
                    throw new Exception("Your Session is expired.");
                }

                ddlStudent.DataTextField = DataTextField;
                ddlStudent.DataValueField = DataValueField;
                ddlStudent.DataBind();

                BindIfNoData(ddlStudent);
            }
            catch (Exception ex)
            {
                Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ex.Message);
            }
        }

        public void BindFeesTypes(int prmClassID, bool prmClearAllFirst)
        {

            if (prmClearAllFirst)
            {
                ddlFees.Items.Clear();
            }
            ddlFees.DataSource = BLGetMastersObj.GetFeesTypes(prmClassID);

            string DataTextField = BLGetMastersObj.Get_DDL_DataText_FieldName("feestype");
            string DataValueField = BLGetMastersObj.Get_DDL_DataValue_FieldName("feestype");

            if (DataTextField.Length == 0 || DataValueField.Length == 0)
            {
                throw new Exception("Your Session is expired.");
            }

            ddlFees.DataTextField = DataTextField;
            ddlFees.DataValueField = DataValueField;
            ddlFees.DataBind();

            BindIfNoData(ddlFees);

        }

        public void BindIfNoData(DropDownList prmDdl)
        {
            if (prmDdl.Items.Count == 0)
            {
                prmDdl.Items.Add(new ListItem("-No Data-", "-1"));
            }
        }
    }
}