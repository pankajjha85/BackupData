﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace SchoolManagementSystem.DataLayer
{
    public class DLGetMasters
    {
        SqlConnection SqlConn;
        DatabaseConnection DBConn;

        private void InitiateConnection()
        {
            DBConn = new DatabaseConnection();
            SqlConn = DBConn.GetSQLConnection();
            SqlConn.Open();
        }

        private void CloseConnection()
        {
            SqlConn.Close();
            SqlConn.Dispose();
            DBConn = null;
        }

        #region [Get Class]
        public DataSet GetClass()
        {
            DataSet DSClass = new DataSet();
            try
            {
                InitiateConnection();

                SqlCommand SqlComm = new SqlCommand("usp_ClassMaster", SqlConn);
                SqlComm.CommandType = CommandType.StoredProcedure;
                DSClass = DBConn.ExecuteGetDataSet(SqlComm);
            }
            catch (Exception ex)
            {
                DataTable DTException = new DataTable();
                DTException.Columns.Add("Result");
                DTException.Columns.Add("Message");
                DataRow dr = DTException.NewRow();
                dr[0] = "Fail";
                dr[1] = ex.Message;
                DTException.Rows.Add(dr);
                DSClass.Tables.Add(DTException);
            }
            finally
            {
                CloseConnection();
            }
            return DSClass;
        }
        #endregion

        #region [Get DIV]
        public DataSet GetDiv(int prmClassID)
        {
            DataSet DSClass = new DataSet();
            try
            {
                InitiateConnection();

                SqlCommand SqlComm = new SqlCommand("usp_DivMaster_ClassMaster", SqlConn);
                SqlComm.CommandType = CommandType.StoredProcedure;
                SqlComm.Parameters.Add(new SqlParameter("@ClassID", prmClassID));
                DSClass = DBConn.ExecuteGetDataSet(SqlComm);
            }
            catch (Exception ex)
            {
                DataTable DTResult=new DataTable();
                DTResult.Columns.Add("Result");
                DTResult.Columns.Add("Message");

                DataRow dr = DTResult.NewRow();
                dr[0] = "Fail";
                dr[1] = ex.Message;
                DTResult.Rows.Add(dr);
                DSClass.Tables.Add(DTResult);
            }
            finally
            {
                CloseConnection();
            }
            return DSClass;
        }
        #endregion

        #region [Get Student Details]
        public DataSet GetStudents(int prmClassID)
        {
            return GetStudents(prmClassID, 0, 0, 0, "NA", 0, (new DateTime(1900, 1, 1)));
        }

        public DataSet GetStudents(int prmClassID, int prmDivID)
        {
            return GetStudents(prmClassID, prmDivID, 0, 0, "NA", 0, (new DateTime(1900, 1, 1)));
        }

        public DataSet GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber)
        {
            return GetStudents(prmClassID, prmDivID, prmStudentRollNumber, 0, "NA", 0, (new DateTime(1900, 1, 1)));
        }

        public DataSet GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID)
        {
            return GetStudents(prmClassID, prmDivID, prmStudentRollNumber, prmStudentAutoID, "NA", 0, (new DateTime(1900, 1, 1)));
        }

        public DataSet GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID, string prmStudentUID)
        {
            return GetStudents(prmClassID, prmDivID, prmStudentRollNumber, prmStudentAutoID, prmStudentUID, 0, (new DateTime(1900, 1, 1)));
        }

        public DataSet GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID, string prmStudentUID, int prmResultStatusAutoID)
        {
            return GetStudents(prmClassID, prmDivID, prmStudentRollNumber, prmStudentAutoID, prmStudentUID, prmResultStatusAutoID, (new DateTime(1900, 1, 1)));
        }

        public DataSet GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID, string prmStudentUID, int prmResultStatusAutoID, DateTime prmAcademicStartDate)
        {
            DataSet DSResult = new DataSet();
            try
            {
                InitiateConnection();

                SqlCommand SqlComm = new SqlCommand("usp_StudentClassRelationshipDetails", SqlConn);
                SqlComm.CommandType = CommandType.StoredProcedure;
                SqlComm.Parameters.Add(new SqlParameter("@ClassID", prmClassID));
                SqlComm.Parameters.Add(new SqlParameter("@DivID", prmDivID));
                SqlComm.Parameters.Add(new SqlParameter("@StudentRollNumber", prmStudentRollNumber));
                SqlComm.Parameters.Add(new SqlParameter("@StudentAutoID", prmStudentAutoID));
                SqlComm.Parameters.Add(new SqlParameter("@StudentUID", prmStudentUID));
                SqlComm.Parameters.Add(new SqlParameter("@ResultStatusAutoID", prmResultStatusAutoID));
                SqlComm.Parameters.Add(new SqlParameter("@AcademicStartDate", prmAcademicStartDate));
                DSResult = DBConn.ExecuteGetDataSet(SqlComm);
            }
            catch (Exception ex)
            {
                DataTable DTException = new DataTable("GetStudents_Exception");
                DTException.Columns.Add("Result");
                DTException.Columns.Add("Message");
                DataRow dr = DTException.NewRow();
                dr[0] = "Fail";
                dr[1] = ex.Message;
                DTException.Rows.Add(dr);
                DSResult.Tables.Add(DTException);
            }
            finally
            {
                CloseConnection();
            }
            return DSResult;
        }
        #endregion

        #region [Get Fees details]

        public DataSet GetFeesTypes(int prmClassID)
        {
            return GetFeesTypes(prmClassID, 0, "");
        }

        public DataSet GetFeesTypes(int prmClassID, int prmFeesComponentID)
        {
            return GetFeesTypes(prmClassID, prmFeesComponentID, "");
        }

        public DataSet GetFeesTypes(int prmClassID, int prmFeesComponentID, string prmMandatory)
        {
            DataSet DSResult = new DataSet();
            try
            {
                InitiateConnection();

                SqlCommand SqlComm = new SqlCommand("usp_ClassFeesComponentMappingDetails", SqlConn);
                SqlComm.CommandType = CommandType.StoredProcedure;
                SqlComm.Parameters.Add(new SqlParameter("@ClassID", prmClassID));
                SqlComm.Parameters.Add(new SqlParameter("@FeesComponentID", prmFeesComponentID));
                SqlComm.Parameters.Add(new SqlParameter("@Mandatory", prmMandatory));
                DSResult = DBConn.ExecuteGetDataSet(SqlComm);
            }
            catch (Exception ex)
            {
                DataTable DTException = new DataTable("GetFeesTypes_Exception");
                DTException.Columns.Add("Result");
                DTException.Columns.Add("Message");
                DataRow dr = DTException.NewRow();
                dr[0] = "Fail";
                dr[1] = ex.Message;
                DTException.Rows.Add(dr);
                DSResult.Tables.Add(DTException);
            }
            finally
            {
                CloseConnection();
            }
            return DSResult;
        }

        #endregion
    }
}