﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace SchoolManagementSystem.DataLayer
{
    public class DLMenu
    {
        SqlConnection SqlConn;
        DatabaseConnection DBConn;

        private void InitiateConnection()
        {
            DBConn = new DatabaseConnection();
            SqlConn = DBConn.GetSQLConnection();
            SqlConn.Open();
        }

        private void CloseConnection()
        {
            SqlConn.Close();
            SqlConn.Dispose();
            DBConn = null;
        }

        public DataSet CreateMenu(int prmRoleID)
        {
            DataSet DSResult = new DataSet();
            try
            {
                InitiateConnection();

                SqlCommand SqlComm = new SqlCommand("usp_GetRoleMenuMappingDetails", SqlConn);
                SqlComm.CommandType = CommandType.StoredProcedure;
                SqlComm.Parameters.Add(new SqlParameter("@RoleID", prmRoleID));

                DSResult = DBConn.ExecuteGetDataSet(SqlComm);

            }
            catch (Exception ex)
            {
                DataTable DTException = new DataTable();
                DTException.Columns.Add("Result");
                DataRow dr = DTException.NewRow();
                dr[0] = ex.Message;
                DTException.Rows.Add(dr);
                DSResult.Tables.Add(DTException);
            }
            finally
            {
                CloseConnection();
            }

            return DSResult;
        }
    }
}