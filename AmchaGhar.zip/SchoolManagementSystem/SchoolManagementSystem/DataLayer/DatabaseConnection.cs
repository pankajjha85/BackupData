﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagementSystem.DataLayer
{
    public class DatabaseConnection
    {
        SqlConnection SQLConn;
        string ConnectionString = string.Empty;

        public SqlConnection GetSQLConnection()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SQLConn = new SqlConnection(ConnectionString);

            return SQLConn;
        }

        public DataTable ExecuteGetDataTable(SqlCommand SQLComm)
        {
            SqlDataAdapter SQLDataAdapterObj = new SqlDataAdapter(SQLComm);
            DataTable DataTableResult = new DataTable();
            SQLDataAdapterObj.Fill(DataTableResult);
            return DataTableResult;
        }

        public DataSet ExecuteGetDataSet(SqlCommand SQLComm)
        {
            SqlDataAdapter SQLDataAdapterObj = new SqlDataAdapter(SQLComm);
            DataSet DataSetResult = new DataSet();
            SQLDataAdapterObj.Fill(DataSetResult);
            return DataSetResult;
        }
    }
}