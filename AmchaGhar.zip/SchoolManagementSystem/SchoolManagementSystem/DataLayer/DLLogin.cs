﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SchoolManagementSystem.DataLayer
{
    public class DLLogin
    {
        SqlConnection SqlConn;
        DatabaseConnection DBConn;

        private void InitiateConnection()
        {
            DBConn = new DatabaseConnection();
            SqlConn = DBConn.GetSQLConnection();
            SqlConn.Open();
        }

        private void CloseConnection()
        {
            SqlConn.Close();
            SqlConn.Dispose();
            DBConn = null;
        }
        

        public DataTable ValidateLoginIDPwd(string prmLoginID, string prmPwd)
        {
            DataTable DTResult = new DataTable();
            try
            {
                InitiateConnection();

                SqlCommand SqlComm = new SqlCommand("usp_ValidateLoginIDPwd", SqlConn);
                SqlComm.CommandType = CommandType.StoredProcedure;
                SqlComm.Parameters.Add(new SqlParameter("@LoginID", prmLoginID));
                SqlComm.Parameters.Add(new SqlParameter("@Password", prmPwd));

                DTResult = DBConn.ExecuteGetDataTable(SqlComm);
                
            }
            catch (Exception ex)
            {
                DTResult.Columns.Add("Result");
                DataRow dr = DTResult.NewRow();
                dr[0] = ex.Message;
                DTResult.Rows.Add(dr);
            }
            finally
            {
                CloseConnection();
            }

            return DTResult;
        }
    }
}