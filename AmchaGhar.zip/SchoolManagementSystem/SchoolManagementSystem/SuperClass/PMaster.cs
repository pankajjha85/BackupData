﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;

using SchoolManagementSystem.Common;
using SchoolManagementSystem.BusinessLayer;

namespace SchoolManagementSystem.SuperClass
{
    public class PMaster : MasterPageBase
    {
        protected DataSet CreateMenu()
        {
            BLMenu BLMenuObj = new BLMenu();
            return BLMenuObj.CreateMenu();
        }

        protected string GetUserLoginID()
        {
            return BLUser.UserLoginID;
        }
    }
}