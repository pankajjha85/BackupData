﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SchoolManagementSystem.BusinessLayer;

namespace SchoolManagementSystem.SuperClass
{
    public class PLogin : System.Web.UI.Page
    {
        string Result = string.Empty;
        protected string ValidateLoginIDPwd(string prmUserName, string prmPassword)
        {
            BLLogin BLLoginObj = new BLLogin();
            Result = BLLoginObj.ValidateLoginIDPwd(prmUserName, prmPassword);
            if (Result == "Success")
            {
                HttpContext.Current.Session["begin"] = DateTime.Now;
            }
            return Result;
        }
    }
}