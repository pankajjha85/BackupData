﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using SchoolManagementSystem.BusinessLayer;

namespace SchoolManagementSystem.Common
{
    public class PageBase : System.Web.UI.Page
    {
        void Page_Init()
        {
            if (HttpContext.Current.Session["begin"] == null)
            {
                BLLogout BLLogoutObj = new BLLogout();
                BLLogoutObj.Logout();
                Response.Redirect(ConfigurationManager.AppSettings["login_page"]);
            }
            
        }
        
    }

    public class MasterPageBase : System.Web.UI.MasterPage
    {
        void Page_Init()
        {
            if (HttpContext.Current.Session["begin"] == null)
            {
                BLLogout BLLogoutObj = new BLLogout();
                BLLogoutObj.Logout();
            }

        }

    }
}