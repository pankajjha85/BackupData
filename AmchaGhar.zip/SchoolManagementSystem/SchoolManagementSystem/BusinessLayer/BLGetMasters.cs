﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using SchoolManagementSystem.DataLayer;
using System.Configuration;

namespace SchoolManagementSystem.BusinessLayer
{
    public class BLGetMasters
    {
        DLGetMasters DLGetMastersObj = new DLGetMasters();

        public DataTable GetClass()
        {
            DataSet DSResult = DLGetMastersObj.GetClass();
            DataTable DTData = null;
            if (DSResult.Tables.Count == 1)
            {
                string Result = Convert.ToString(DSResult.Tables[0].Rows[0]["Result"]);
                if (Result == "Fail")
                {
                    string ErrorMessage = Convert.ToString(DSResult.Tables[0].Rows[0]["Message"]);
                    HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ErrorMessage);
                }

            }
            else if (DSResult.Tables.Count > 1)
            {
                int DataTable_Index_In_DataSet = Convert.ToInt32(DSResult.Tables[0].Rows[0]["Data"]);
                DTData = DSResult.Tables[DataTable_Index_In_DataSet];

                int DDLData_Index_In_DataSet = Convert.ToInt32(DSResult.Tables[0].Rows[0]["ClassDDLData"]);
                string DDL_DataValue_Field_Name = Convert.ToString(DSResult.Tables[DDLData_Index_In_DataSet].Rows[0]["Value"]);
                string DDL_DataText_Field_Name = Convert.ToString(DSResult.Tables[DDLData_Index_In_DataSet].Rows[0]["Text"]);

                HttpContext.Current.Session["DDLClass_DataValue_Field_Name"] = DDL_DataValue_Field_Name;
                HttpContext.Current.Session["DDLClass_DataText_Field_Name"] = DDL_DataText_Field_Name;
            }
            return DTData;
        }

        #region [get Div]
        public DataTable GetDiv(int prmClassID)
        {
            DataSet DSResult = DLGetMastersObj.GetDiv(prmClassID);
            DataTable DTData = null;
            if (DSResult.Tables.Count == 1)
            {
                string Result = Convert.ToString(DSResult.Tables[0].Rows[0]["Result"]);
                if (Result == "Fail")
                {
                    string ErrorMessage = Convert.ToString(DSResult.Tables[0].Rows[0]["Message"]);
                    HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ErrorMessage);
                }

            }
            else if (DSResult.Tables.Count > 1)
            {
                int DataTable_Index_In_DataSet = Convert.ToInt32(DSResult.Tables[0].Rows[0]["Data"]);
                DTData = DSResult.Tables[DataTable_Index_In_DataSet];

                int DDLData_Index_In_DataSet = Convert.ToInt32(DSResult.Tables[0].Rows[0]["DDLData"]);
                string DDL_DataValue_Field_Name = Convert.ToString(DSResult.Tables[DDLData_Index_In_DataSet].Rows[0]["Value"]);
                string DDL_DataText_Field_Name = Convert.ToString(DSResult.Tables[DDLData_Index_In_DataSet].Rows[0]["Text"]);

                HttpContext.Current.Session["DDLDiv_DataValue_Field_Name"] = DDL_DataValue_Field_Name;
                HttpContext.Current.Session["DDLDiv_DataText_Field_Name"] = DDL_DataText_Field_Name;
            }
            return DTData;
        }
        #endregion

        public string Get_DDL_DataValue_FieldName(string prmMatch)
        {
            string Result = "NA";
            switch (prmMatch)
            {
                case "class": Result = (HttpContext.Current.Session["DDLClass_DataValue_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLClass_DataValue_Field_Name"]));
                    break;
                case "div": Result = (HttpContext.Current.Session["DDLDiv_DataValue_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLDiv_DataValue_Field_Name"]));
                    break;
                case "rollnumber": Result = (HttpContext.Current.Session["DDLRollNumber_DataValue_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLRollNumber_DataValue_Field_Name"]));
                    break;
                case "student": Result = (HttpContext.Current.Session["DDLStudent_DataValue_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLStudent_DataValue_Field_Name"]));
                    break;
                case "feestype": Result = (HttpContext.Current.Session["DDLFeesTypes_DataValue_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLFeesTypes_DataValue_Field_Name"]));
                    break;
            }
            return Result;
        }

        public string Get_DDL_DataText_FieldName(string prmMatch)
        {
            string Result = "NA";
            switch (prmMatch)
            {
                case "class": Result = (HttpContext.Current.Session["DDLClass_DataText_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLClass_DataText_Field_Name"]));
                    break;
                case "div": Result = (HttpContext.Current.Session["DDLDiv_DataText_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLDiv_DataText_Field_Name"]));
                    break;
                case "rollnumber": Result = (HttpContext.Current.Session["DDLRollNumber_DataText_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLRollNumber_DataText_Field_Name"]));
                    break;
                case "student": Result = (HttpContext.Current.Session["DDLStudent_DataText_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLStudent_DataText_Field_Name"]));
                    break;
                case "feestype": Result = (HttpContext.Current.Session["DDLFeesTypes_DataText_Field_Name"] == null ? "NA" : Convert.ToString(HttpContext.Current.Session["DDLFeesTypes_DataText_Field_Name"]));
                    break;
            }
            return Result;
        }

        #region [Process Student/Rollnumber data]
        public DataTable ProcessStudentDetails(DataSet prmDSGetStudents)
        {
            DataTable DTGetStudents = new DataTable();
            try
            {
                if (prmDSGetStudents.Tables.Count == 1)
                {
                    string ErrorMessage = Convert.ToString(prmDSGetStudents.Tables[0].Rows[0]["Message"]);
                    HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ErrorMessage);
                }
                else if (prmDSGetStudents.Tables.Count > 1)
                {
                    int DataTable_Index_In_DataSet = Convert.ToInt32(prmDSGetStudents.Tables[0].Rows[0]["Data"]);
                    DTGetStudents = prmDSGetStudents.Tables[DataTable_Index_In_DataSet];

                    int DDLRollNumberData_Index_In_DataSet = Convert.ToInt32(prmDSGetStudents.Tables[0].Rows[0]["RollNumberDDLData"]);
                    string DDLRollNumber_DataValue_Field_Name = Convert.ToString(prmDSGetStudents.Tables[DDLRollNumberData_Index_In_DataSet].Rows[0]["Value"]);
                    string DDLRollNumber_DataText_Field_Name = Convert.ToString(prmDSGetStudents.Tables[DDLRollNumberData_Index_In_DataSet].Rows[0]["Text"]);

                    HttpContext.Current.Session["DDLRollNumber_DataValue_Field_Name"] = DDLRollNumber_DataValue_Field_Name;
                    HttpContext.Current.Session["DDLRollNumber_DataText_Field_Name"] = DDLRollNumber_DataText_Field_Name;

                    int DDLStudentData_Index_In_DataSet = Convert.ToInt32(prmDSGetStudents.Tables[0].Rows[0]["StudentDDLData"]);
                    string DDLStudent_DataValue_Field_Name = Convert.ToString(prmDSGetStudents.Tables[DDLStudentData_Index_In_DataSet].Rows[0]["Value"]);
                    string DDLStudent_DataText_Field_Name = Convert.ToString(prmDSGetStudents.Tables[DDLStudentData_Index_In_DataSet].Rows[0]["Text"]);

                    HttpContext.Current.Session["DDLStudent_DataValue_Field_Name"] = DDLStudent_DataValue_Field_Name;
                    HttpContext.Current.Session["DDLStudent_DataText_Field_Name"] = DDLStudent_DataText_Field_Name;
                }
            }
            catch (Exception ex)
            {
                DTGetStudents = null;
                HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ex.Message);
            }
            return DTGetStudents;
        }

        #endregion

        #region [Get Student details]
        public DataTable GetStudents(int prmClassID)
        {
            return ProcessStudentDetails(DLGetMastersObj.GetStudents(prmClassID));
        }

        public DataTable GetStudents(int prmClassID, int prmDivID)
        {
            return ProcessStudentDetails(DLGetMastersObj.GetStudents(prmClassID, prmDivID));
        }

        public DataTable GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber)
        {
            return ProcessStudentDetails(DLGetMastersObj.GetStudents(prmClassID, prmDivID, prmStudentRollNumber));
        }

        public DataTable GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID)
        {
            return ProcessStudentDetails(DLGetMastersObj.GetStudents(prmClassID, prmDivID, prmStudentRollNumber, prmStudentAutoID));
        }

        public DataTable GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID, string prmStudentUID)
        {
            return ProcessStudentDetails(DLGetMastersObj.GetStudents(prmClassID, prmDivID, prmStudentRollNumber, prmStudentAutoID, prmStudentUID));
        }

        public DataTable GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID, string prmStudentUID, int prmResultStatusAutoID)
        {
            return ProcessStudentDetails(DLGetMastersObj.GetStudents(prmClassID, prmDivID, prmStudentRollNumber, prmStudentAutoID, prmStudentUID, prmResultStatusAutoID));
        }

        public DataTable GetStudents(int prmClassID, int prmDivID, int prmStudentRollNumber, int prmStudentAutoID, string prmStudentUID, int prmResultStatusAutoID, DateTime prmAcademicStartDate)
        {
            return ProcessStudentDetails(DLGetMastersObj.GetStudents(prmClassID, prmDivID, prmStudentRollNumber, prmStudentAutoID, prmStudentUID, prmResultStatusAutoID, prmAcademicStartDate));
        }

        #endregion

        #region [Process Student/Rollnumber data]
        public DataTable ProcessFeesTypes(DataSet prmDSGetFeesTypes)
        {
            DataTable DTGetFeesTypes = new DataTable();
            try
            {
                if (prmDSGetFeesTypes.Tables.Count == 1)
                {
                    string ErrorMessage = Convert.ToString(prmDSGetFeesTypes.Tables[0].Rows[0]["Message"]);
                    HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ErrorMessage);
                }
                else if (prmDSGetFeesTypes.Tables.Count > 1)
                {
                    int DataTable_Index_In_DataSet = Convert.ToInt32(prmDSGetFeesTypes.Tables[0].Rows[0]["Data"]);
                    DTGetFeesTypes = prmDSGetFeesTypes.Tables[DataTable_Index_In_DataSet];

                    int DDLFeesTypesData_Index_In_DataSet = Convert.ToInt32(prmDSGetFeesTypes.Tables[0].Rows[0]["FeesTypeDDLData"]);
                    string DDLFeesTypes_DataValue_Field_Name = Convert.ToString(prmDSGetFeesTypes.Tables[DDLFeesTypesData_Index_In_DataSet].Rows[0]["Value"]);
                    string DDLFeesTypes_DataText_Field_Name = Convert.ToString(prmDSGetFeesTypes.Tables[DDLFeesTypesData_Index_In_DataSet].Rows[0]["Text"]);

                    HttpContext.Current.Session["DDLFeesTypes_DataValue_Field_Name"] = DDLFeesTypes_DataValue_Field_Name;
                    HttpContext.Current.Session["DDLFeesTypes_DataText_Field_Name"] = DDLFeesTypes_DataText_Field_Name;

                }
            }
            catch (Exception ex)
            {
                DTGetFeesTypes = null;
                HttpContext.Current.Response.Redirect(ConfigurationManager.AppSettings["error_page"] + ex.Message);
            }
            return DTGetFeesTypes;
        }

        #endregion

        #region [Get Fees Types details]
        public DataTable GetFeesTypes(int prmClassID)
        {
            return ProcessFeesTypes(DLGetMastersObj.GetFeesTypes(prmClassID));
        }

        public DataTable GetFeesTypes(int prmClassID, int prmFeesComponentID)
        {
            return ProcessFeesTypes(DLGetMastersObj.GetFeesTypes(prmClassID, prmFeesComponentID));
        }

        public DataTable GetFeesTypes(int prmClassID, int prmFeesComponentID, string prmMandatory)
        {
            return ProcessFeesTypes(DLGetMastersObj.GetFeesTypes(prmClassID, prmFeesComponentID, prmMandatory));
        }

        #endregion
    }
}