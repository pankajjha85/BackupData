﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using SchoolManagementSystem.DataLayer;

namespace SchoolManagementSystem.BusinessLayer
{
    public class BLMenu
    {
        public DataSet CreateMenu()
        {
            int UserRoleID = BLUser.UserRoleID;

            DLMenu DLMenuObj = new DLMenu();
            return DLMenuObj.CreateMenu(UserRoleID);
        }
    }
}