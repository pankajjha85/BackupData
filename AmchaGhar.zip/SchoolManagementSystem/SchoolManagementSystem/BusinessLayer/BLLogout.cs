﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagementSystem.BusinessLayer
{
    public class BLLogout
    {
        public void Logout()
        {
            HttpContext.Current.Session.Abandon();
        }
    }
}