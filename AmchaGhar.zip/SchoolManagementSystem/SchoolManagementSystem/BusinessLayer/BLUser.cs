﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolManagementSystem.BusinessLayer
{
    public static class BLUser
    {
        public static int UserRoleID { get; set; }
        public static string UserRoleName { get; set; }
        public static string UserIsAdmin { get; set; }
        public static string UserIsVolunteer { get; set; }
        public static string UserLoginID { get; set; }
    }
}