﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security;
using SchoolManagementSystem.DataLayer;
using System.Data;

namespace SchoolManagementSystem.BusinessLayer
{
    public class BLLogin
    {
        string Result = string.Empty;

        public string ValidateLoginIDPwd(string prmLoginID, string prmPwd)
        {
            BLSecurity BLSecurityObj = new BLSecurity();
            prmPwd = BLSecurityObj.Encryptdata(prmPwd);

            DLLogin DLLoginObj = new DLLogin();
            DataTable DTResult = DLLoginObj.ValidateLoginIDPwd(prmLoginID, prmPwd);
            DataRow DataRowObj = DTResult.Rows[0];

            
            Result = Convert.ToString(DataRowObj["Result"]);

            switch (Result)
            {
                case "LoginIDNotExists": Result = "Invalid Login ID.";
                    break;
                case "PasswordIncorrect": Result = "Invalid Password.";
                    break;
                case "Success":
                    BLUser.UserRoleID = Convert.ToInt32(Convert.ToString(DataRowObj["RoleAutoID"]));
                    BLUser.UserRoleName = Convert.ToString(DataRowObj["RoleName"]);
                    BLUser.UserIsAdmin = Convert.ToString(DataRowObj["IsAdmin"]);
                    BLUser.UserIsVolunteer = Convert.ToString(DataRowObj["IsVolunteer"]);
                    BLUser.UserLoginID = Convert.ToString(DataRowObj["LoginID"]);
                    break;
            }
            return Result;
        }
    }
}