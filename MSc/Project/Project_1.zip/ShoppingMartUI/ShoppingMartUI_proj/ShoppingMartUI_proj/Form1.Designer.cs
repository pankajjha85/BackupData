﻿namespace ShoppingMartUI_proj
{
    partial class FormMainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGetProducts = new System.Windows.Forms.Button();
            this.txtProductList = new System.Windows.Forms.TextBox();
            this.rbmale = new System.Windows.Forms.RadioButton();
            this.rbfemale = new System.Windows.Forms.RadioButton();
            this.ddlIsBranded = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGetProducts
            // 
            this.btnGetProducts.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetProducts.Location = new System.Drawing.Point(32, 103);
            this.btnGetProducts.Name = "btnGetProducts";
            this.btnGetProducts.Size = new System.Drawing.Size(283, 37);
            this.btnGetProducts.TabIndex = 0;
            this.btnGetProducts.Text = "GET PRODUCTS FOR ME";
            this.btnGetProducts.UseVisualStyleBackColor = true;
            this.btnGetProducts.Click += new System.EventHandler(this.btnGetProducts_Click);
            // 
            // txtProductList
            // 
            this.txtProductList.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductList.Location = new System.Drawing.Point(32, 157);
            this.txtProductList.Name = "txtProductList";
            this.txtProductList.Size = new System.Drawing.Size(10, 26);
            this.txtProductList.TabIndex = 1;
            // 
            // rbmale
            // 
            this.rbmale.AutoSize = true;
            this.rbmale.Checked = true;
            this.rbmale.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbmale.Location = new System.Drawing.Point(114, 28);
            this.rbmale.Name = "rbmale";
            this.rbmale.Size = new System.Drawing.Size(66, 22);
            this.rbmale.TabIndex = 1;
            this.rbmale.TabStop = true;
            this.rbmale.Text = "MALE";
            this.rbmale.UseVisualStyleBackColor = true;
            // 
            // rbfemale
            // 
            this.rbfemale.AutoSize = true;
            this.rbfemale.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbfemale.Location = new System.Drawing.Point(198, 28);
            this.rbfemale.Name = "rbfemale";
            this.rbfemale.Size = new System.Drawing.Size(86, 22);
            this.rbfemale.TabIndex = 2;
            this.rbfemale.Text = "FEMALE";
            this.rbfemale.UseVisualStyleBackColor = true;
            // 
            // ddlIsBranded
            // 
            this.ddlIsBranded.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlIsBranded.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ddlIsBranded.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddlIsBranded.FormattingEnabled = true;
            this.ddlIsBranded.Items.AddRange(new object[] {
            "BRANDED ITEMS",
            "NON BRANDED"});
            this.ddlIsBranded.Location = new System.Drawing.Point(32, 65);
            this.ddlIsBranded.Name = "ddlIsBranded";
            this.ddlIsBranded.Size = new System.Drawing.Size(184, 26);
            this.ddlIsBranded.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "I AM A";
            // 
            // FormMainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 464);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ddlIsBranded);
            this.Controls.Add(this.rbfemale);
            this.Controls.Add(this.rbmale);
            this.Controls.Add(this.txtProductList);
            this.Controls.Add(this.btnGetProducts);
            this.Name = "FormMainPage";
            this.Text = "SHOPPING MART";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGetProducts;
        private System.Windows.Forms.TextBox txtProductList;
        private System.Windows.Forms.RadioButton rbmale;
        private System.Windows.Forms.RadioButton rbfemale;
        private System.Windows.Forms.ComboBox ddlIsBranded;
        private System.Windows.Forms.Label label1;
    }
}

