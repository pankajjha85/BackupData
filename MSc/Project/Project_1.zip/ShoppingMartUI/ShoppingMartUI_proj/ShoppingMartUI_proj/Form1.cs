﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace ShoppingMartUI_proj
{
    public partial class FormMainPage : Form
    {
        public FormMainPage()
        {
            InitializeComponent();
        }

        private void btnGetProducts_Click(object sender, EventArgs e)
        {
            string cmd = @"D:\Pankaj\Others\Personal\MSc\Part-2\Project\txt_to_mongo.py";
            string gender = "M";
            if (rbfemale.Checked)
                gender = "F";

            string show_branded = "true";
            if (ddlIsBranded.SelectedIndex == 1)
                show_branded = "false";

            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "c:/anaconda3/python.exe";
            start.Arguments = cmd + " " + gender + "|" + show_branded;
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            using (Process process = Process.Start(start))
            {
                string s = "";
                using (StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadToEnd();
                    s = s + result;
                }
                txtProductList.Text = s;
            }
            
            if (txtProductList.Text.IndexOf('|') >= 0)
            {
                FormMainPage this_form = new FormMainPage();
                DataTable dt = this_form.CreateProductsDT(txtProductList.Text);
                FormProductList FormProductListObj = new FormProductList();
                DataGrid gv = new DataGrid();
                gv.DataSource = dt;
                gv.Width = 700;
                gv.Height = 300;
                FormProductListObj.Controls.Add(gv);
                FormProductListObj.Visible = true;
            }



        }
        public DataTable CreateProductsDT(string products)
        {
            DataTable dt = new DataTable();
            try
            {
                DataRow dr;
                dt.Columns.Add(new DataColumn("asin"));
                dt.Columns.Add(new DataColumn("title"));
                dt.Columns.Add(new DataColumn("imUrl"));
                dt.Columns.Add(new DataColumn("avgRatingByProduct"));
                products = products.Replace("\r\n", "");
                foreach (string each_product in products.Split('|'))
                {
                    if (each_product.Length > 0)
                    {
                        dr = dt.NewRow();
                        //char[] separator = "[;]".ToCharArray();
                        string[] each_product_fields = each_product.Split('~');
                        dr[0] = each_product_fields[0];
                        dr[1] = each_product_fields[1];
                        dr[2] = each_product_fields[2];
                        dr[3] = each_product_fields[3];
                        dt.Rows.Add(dr);
                    }
                }
            }
            catch (Exception ex)
            {
                dt.Columns.Add(new DataColumn("Result"));
                dt.Columns.Add(new DataColumn("Message"));
                DataRow dr = dt.NewRow();
                dr[0] = "Fail";
                dr[1] = "Unable to load the products. " + ex.Message;
                dt.Rows.Add(dr);
            }
            return dt;
        }

        //private void button1_Click(object sender, EventArgs e)
        //{
        //    var request = WebRequest.Create("http://www.gravatar.com/avatar/6810d91caff032b202c50701dd3af745?d=identicon&r=PG");

        //    using (var response = request.GetResponse())
        //    using (var stream = response.GetResponseStream())
        //    {
        //        pictureBox1.Image = Bitmap.FromStream(stream);
        //    }
        //}
    }
}
