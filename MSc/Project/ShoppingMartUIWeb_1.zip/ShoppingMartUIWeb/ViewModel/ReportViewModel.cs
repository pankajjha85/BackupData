﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ShoppingMartUIWeb.Model;

namespace ShoppingMartUIWeb.ViewModel
{
    public class ReportViewModel
    {
        public string batch_id { get; set; }
        public string gender { get; set; }
        public string show_price { get; set; }
        public string show_related { get; set; }
        public string show_brand { get; set; }
        public string process_status { get; set; }
        public List<ReportModel> list_report_model { get; set; }
        public string response { get; set; }
        public string message { get; set; }
        public string message_type { get; set; }
        public bool ShowRefresh { get; set; }
        public int image_width { get; set; }
        public int image_height { get; set; }
        public string search_title { get; set; }
        public bool review_exists { get; set; }
        public List<string> Category1 { get; set; }
        public List<string> Category2 { get; set; }
        public List<string> Category3 { get; set; }
        public List<string> Category4 { get; set; }
        public List<string> Category5 { get; set; }
        public List<string> Category6 { get; set; }
    }
}