﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingMartUIWeb
{
    public partial class form1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<int> numbers = new List<int>() { 35, 44, 200, 84, 3987, 4, 199, 329, 446, 208 };
            IEnumerable<IGrouping<int, int>> query = from number in numbers
                        group number by number % 2;
            String s = "";
            
            foreach(var q in query)
            {
                if(q.Key==0)
                {
                    s = s + "even-number = ";
                }
                else
                {
                    s = s + "odd-number = ";
                }
                foreach(int i in q)
                {
                    s = s + (i.ToString()) + ",";
                }
            }
            txt1.Text = s;
        }
    }
}