﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingMartUIWeb.Model;
using ShoppingMartUIWeb.BAL;

namespace ShoppingMartUIWeb.Controllers
{
    public class AuthenticationController : Controller
    {
        // GET: Authentication
        public ActionResult Login()
        {
            ViewData["Message"] = "";
            return View("Login");
        }

        [HttpPost]
        public ActionResult Authenticate(string InputEmail, string InputPassword)
        {
            BALAuthentication BALAuthenticationObj = new BALAuthentication();
            UserStatus result = BALAuthenticationObj.Authenticate(InputEmail, InputPassword);
            ViewData["Message"] = "";
            if (result == UserStatus.NonAuthenticatedUser)
            {
                ViewData["Message"] = "Invalid User name or Password";
                return View("Login");
            }
            return View("Login");
        }

        public ActionResult Register()
        {
            return View("Register");
        }

        [HttpPost]
        public ActionResult Register(string InputEmail, string InputPassword)
        {
            return View("Register");
        }
    }
}