﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using ShoppingMartUIWeb.BAL;
using System.Text;
using Newtonsoft.Json;
using ShoppingMartUIWeb.ViewModel;
using System.Diagnostics;
using System.IO;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using ShoppingMartUIWeb.Model;

namespace ShoppingMartUIWeb.Controllers
{
    public class ProductApiController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage GetReviewDetails(string id)
        {
            string asin = id;
            BALProduct BALProductObj = new BALProduct();
            DataTable dt = BALProductObj.get_product_review_details(asin);


            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return response;
        }

        [HttpGet]
        public HttpResponseMessage GetReviewAll(string id)
        {
            string asin = id;
            BALProduct BALProductObj = new BALProduct();
            DataTable dt = BALProductObj.get_product_review_all(asin);


            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return response;
        }

        [HttpPost]
        public HttpResponseMessage SubmitRequest(RequestDetailsModel RDM)
        {
            DataTable dt = new DataTable();
            BALReport BALReportObj = new BALReport();
            string batchID = DateTime.Now.ToString("yyyyMMddhhmmss");
            RDM.batch_id = batchID;
            dt = BALReportObj.updateRequest(RDM.batch_id, RDM.gender, RDM.show_price, RDM.show_related, RDM.show_brand, RDM.categories);
            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var output = this.Request.CreateResponse(HttpStatusCode.OK);
            output.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return output;
        }

        [HttpGet]
        public HttpResponseMessage GetRecommendedProducts(string id)
        {
            ReportViewModel RVM = new ReportViewModel();
            DataTable dt = new DataTable();
            string batchID = id;

            if (batchID.Length > 0)
            {
                batchID = DateTime.Now.ToString("yyyyMMddhhmmss");
                RVM.batch_id = batchID;

                BALReport BALReportObj = new BALReport();

                DataTable dt_response = new DataTable();
                GetPythonResult("get_recommended_items");
                BsonDocument bson_doc_response = BALReportObj.getResponse(RVM.batch_id);
                BsonArray bson_arr_response = new BsonArray();
                try
                {
                    bson_arr_response = bson_doc_response["response"].AsBsonArray;

                    dt_response.Columns.Add(new DataColumn("asin"));
                    dt_response.Columns.Add(new DataColumn("title"));
                    dt_response.Columns.Add(new DataColumn("url"));
                    dt_response.Columns.Add(new DataColumn("avg_rating"));

                    foreach (BsonArray each_response in bson_arr_response)
                    {
                        DataRow dr = dt_response.NewRow();
                        int i = 0;
                        foreach (var element in each_response)
                        {
                            dr[i] = element;
                            i++;
                        }
                        dt_response.Rows.Add(dr);
                    }
                }
                catch (Exception ex)
                {
                    dt_response = new DataTable();
                    dt_response.Columns.Add(new DataColumn("asin"));
                    dt_response.Columns.Add(new DataColumn("title"));
                    dt_response.Columns.Add(new DataColumn("url"));
                    dt_response.Columns.Add(new DataColumn("avg_rating"));
                    DataRow dr = dt_response.NewRow();
                    dr[0] = "";
                    dr[1] = bson_doc_response["Message"].AsString;
                    dr[2] = "";
                    dr[3] = 0;
                    dt_response.Rows.Add(dr);
                }
                if (dt_response != null && dt_response.Rows.Count > 0)
                {
                    dt = dt_response.Copy();
                }
            }
            else
            {
                dt = new DataTable();
                dt.Columns.Add(new DataColumn("asin"));
                dt.Columns.Add(new DataColumn("title"));
                dt.Columns.Add(new DataColumn("url"));
                dt.Columns.Add(new DataColumn("avg_rating"));
                DataRow dr = dt.NewRow();
                dr[0] = "";
                dr[1] = "Session expired. Please search again";
                dr[2] = "";
                dr[3] = 0;
                dt.Rows.Add(dr);
            }

            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var output = this.Request.CreateResponse(HttpStatusCode.OK);
            output.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return output;
        }

        [HttpGet]
        public HttpResponseMessage GetProductsByTitle(string id)
        {
            string search_value = id;
            string search_by = "title";
            DataTable dt_response = new DataTable();
            if (search_value.Trim().Length > 0)
            {
                string batch_id = DateTime.Now.ToString("yyyyMMddhhmmss");
                BALProduct BALProductObj = new BALProduct();
                BALProductObj.request_product_search(batch_id, search_by, search_value);
                GetPythonResult("search_product_by_title");
                BsonDocument bson_search_response = BALProductObj.get_search_response(batch_id);
                BsonArray bson_arr_search_response = new BsonArray();
                try
                {
                    bson_arr_search_response = bson_search_response["search_response"].AsBsonArray;

                    dt_response.Columns.Add(new DataColumn("asin"));
                    dt_response.Columns.Add(new DataColumn("title"));
                    dt_response.Columns.Add(new DataColumn("url"));

                    foreach (BsonArray each_response in bson_arr_search_response)
                    {
                        DataRow dr = dt_response.NewRow();
                        int i = 0;
                        foreach (var element in each_response)
                        {
                            dr[i] = element;
                            i++;
                        }
                        dt_response.Rows.Add(dr);
                    }
                }
                catch (Exception)
                {
                    dt_response = new DataTable();
                    dt_response.Columns.Add(new DataColumn("asin"));
                    dt_response.Columns.Add(new DataColumn("title"));
                    dt_response.Columns.Add(new DataColumn("url"));
                    DataRow dr = dt_response.NewRow();
                    dr[0] = "";
                    dr[1] = bson_arr_search_response["Message"].AsString;
                    dr[2] = "";
                    dr[3] = 0;
                    dt_response.Rows.Add(dr);
                }
            }

            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt_response);

            string yourJson = JSONresult;
            var output = this.Request.CreateResponse(HttpStatusCode.OK);
            output.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return output;
        }

        [HttpGet]
        public HttpResponseMessage GetCategoryMaster(string id, string id1, string id2, string id3, string id4, string id5)
        {
            //
            return null;
        }

        public string GetPythonResult(string function_name)
        {
            ProcessStartInfo start = new ProcessStartInfo();
            start.FileName = "D:/Program Files (x86)/Anaconda3/python.exe";
            start.Arguments = "D:/Pankaj/Others/Personal/MSc/Part-2/Project/ShoppingMartUIWeb/ShoppingMartUIWeb/ShoppingMartUIWeb/Python/txt_to_mongo.py" + " " + function_name;
            start.UseShellExecute = false;
            start.RedirectStandardOutput = true;
            string s = "";
            using (Process process = Process.Start(start))
            {
                using (StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadToEnd();
                    s = s + result;
                }
            }
            return s;
        }
    }
}
