﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ShoppingMartUIWeb.BAL;
using ShoppingMartUIWeb.Model;
using ShoppingMartUIWeb.ViewModel;
using System.Data;

namespace ShoppingMartUIWeb.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Load()
        {
            ReportViewModel RVM = new ReportViewModel();
            BALReport BALReportObj = new BALReport();
            RVM.Category1 = BALReportObj.GetCategories();
            RVM.batch_id = "";
            RVM.gender = "M";
            RVM.show_price = "true";
            RVM.show_related = "true";
            RVM.show_brand = "y";
            RVM.process_status = "ready";
            RVM.message = "";
            RVM.message_type = "";
            RVM.ShowRefresh = false;
            RVM.search_title = "";
            return View("load", RVM);
        }

        [HttpPost]
        public ActionResult requestItems(string gender, string branded)
        {
            ReportViewModel RVM = new ReportViewModel();
            if (gender.Length > 0 && branded.Length > 0)
            {
                string batchID = DateTime.Now.ToString("yyyyMMddhhmmss");
                RVM.batch_id = batchID;
                
                RVM.gender = gender;
                RVM.show_price = "true";
                RVM.show_related = "true";
                RVM.show_brand = branded;
                RVM.process_status = "ready";
                RVM.search_title = "";
                BALReport BALReportObj = new BALReport();
                DataTable dt = BALReportObj.updateRequest(RVM.batch_id, RVM.gender, RVM.show_price, RVM.show_related, RVM.show_brand, "");
                RVM.message = Convert.ToString(dt.Rows[0]["Message"]);
                RVM.message_type = "info";
                RVM.ShowRefresh = true;

                Session["batch_id"] = RVM.batch_id;
                Session["gender"] = RVM.gender;
                Session["branded"] = RVM.show_brand;
            }
            return View("load", RVM);
        }
        public ActionResult getResponse(string id)
        {
            string batch_id = id;
            
            ReportViewModel RVM = new ReportViewModel();
            if (batch_id == "")
            {
                RVM.batch_id = "";
                RVM.gender = "M";
                RVM.show_price = "true";
                RVM.show_related = "true";
                RVM.show_brand = "y";
                RVM.process_status = "ready";
                RVM.search_title = "";
                RVM.message = "Session expired in between. Please refine your search and submit.";
                RVM.message_type = "error";
                RVM.ShowRefresh = false;
            }
            else
            {
                string gender = Convert.ToString(Session["gender"]);
                string branded = Convert.ToString(Session["branded"]);
                BALReport BALReportObj = new BALReport();
                #region [Commented code]
                //DataTable dt = BALReportObj.getResponse(batch_id);
                //string status = Convert.ToString(dt.Rows[0]["Status"]);
                //if (status.ToLower() == "fail")
                //{
                //    RVM.batch_id = "";
                //    RVM.gender = "M";
                //    RVM.show_price = "true";
                //    RVM.show_related = "true";
                //    RVM.show_brand = "y";
                //    RVM.process_status = "error";
                //    RVM.search_title = "";
                //    RVM.message = "We are sorry, some error occured while searching for the products for you. You can try to refine your search and submit it again."+ Convert.ToString(dt.Rows[0]["Message"]);
                //    RVM.message_type = "error";
                //    RVM.ShowRefresh = false;
                //}
                //else
                //{
                //    RVM.batch_id = batch_id;
                //    RVM.gender = gender;
                //    RVM.show_price = "true";
                //    RVM.show_related = "true";
                //    RVM.show_brand = branded;
                //    RVM.search_title = "";

                //    string process_status = Convert.ToString(dt.Rows[0]["ProcessStatus"]);
                //    RVM.process_status = process_status;
                //    if (RVM.process_status.ToLower() == "pending" || RVM.process_status.ToLower() == "ready")
                //    {
                //        RVM.message = "Searching the best products for you is in progress, please stand by.";
                //        RVM.message_type = "info";
                //        RVM.ShowRefresh = true;
                //    }
                //    else if(RVM.process_status.ToLower() == "processed")
                //    {
                //        string response = Convert.ToString(dt.Rows[0]["Response"]);
                //        DataTable dt_response = new DataTable();
                //        dt_response.Columns.Add(new DataColumn("asin"));
                //        dt_response.Columns.Add(new DataColumn("title"));
                //        dt_response.Columns.Add(new DataColumn("url"));
                //        dt_response.Columns.Add(new DataColumn("avg_rating"));

                //        RVM.ShowRefresh = false;
                //        RVM.list_report_model = new List<ReportModel>();
                //        RVM.review_exists = true;
                //        foreach (var product in response.Split('|'))
                //        {
                //            if (product.Length > 0)
                //            {
                //                string[] details = product.Split('~');
                //                ReportModel RM = new ReportModel();
                //                RM.asin = details[0];
                //                RM.title = details[1];
                //                RM.url = details[2];
                //                RM.avg_rating_by_product = Convert.ToDouble(details[3]);
                //                RVM.list_report_model.Add(RM);
                //            }
                //        }
                //        if (RVM.list_report_model.Count > 0)
                //        {
                //            RVM.message = "Below are the list of products recommended for you.";
                //            RVM.message_type = "success";
                //            RVM.image_height = 200;
                //            RVM.image_width = 200;
                //        }
                //        Session["RVM"] = RVM;
                //    }                    
                //}
                #endregion
            }
            return View("load", RVM);
        }

        [HttpPost]
        public ActionResult search(string search)
        {
            string search_title = search;
            ReportViewModel RVM = new ReportViewModel();
            //RVM.batch_id = "";
            //RVM.gender = "";
            //RVM.image_height = 200;
            //RVM.image_width = 200;
            
            //RVM.search_title = search_title;
            //RVM.list_report_model = new List<ReportModel>();

            //BALProduct BALProductObj = new BALProduct();
            //var documents = BALProductObj.get_product_by_search(search_title);
            
            //foreach(var doc in documents)
            //{
            //    ReportModel RM = new ReportModel();
            //    RM.asin = doc["asin"].AsString;
            //    RM.title = doc["title"].AsString;
            //    RM.url = doc["imUrl"].AsString;
            //    RVM.list_report_model.Add(RM);
            //}
            //if(RVM.list_report_model.Count>0)
            //{
            //    RVM.message = "Below products has been matched with your search criteria";
            //    RVM.message_type = "success";
            //}
            //else
            //{
            //    RVM.message = "No products found matching your search criteria. Please refine your search.";
            //    RVM.message_type = "error";
            //}
            //RVM.process_status = "";
            //RVM.response = "";
            //RVM.show_brand = "";
            //RVM.show_price = "true";
            //RVM.show_related = "true";
            //RVM.ShowRefresh = false;
            //RVM.review_exists = false;
            return View("load", RVM);
        }

    }
}