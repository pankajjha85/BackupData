﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using ShoppingMartUIWeb.BAL;
using Newtonsoft.Json;
using System.Text;

namespace ShoppingMartUIWeb.Controllers
{
    public class CategoryAPIController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage GetCategory2(string id)
        {
            string category1 = id;
            BALReport BALReportObj = new BALReport();
            List<string> category2 = BALReportObj.GetCategories(category1);
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Category2"));
            dt.Columns.Add(new DataColumn("SelectedCategory1"));
            DataRow dr;
            foreach (string cat in category2)
            {
                dr = dt.NewRow();
                dr[0] = cat;
                dr[1] = category1;
                dt.Rows.Add(dr);
            }

            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return response;
        }

        [HttpGet]
        public HttpResponseMessage GetCategory3(string id, string id1)
        {
            string category1 = id;
            string category2 = id1;

            BALReport BALReportObj = new BALReport();
            List<string> category3 = BALReportObj.GetCategories(category1, category2);
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Category3"));
            dt.Columns.Add(new DataColumn("SelectedCategory1"));
            dt.Columns.Add(new DataColumn("SelectedCategory2"));
            DataRow dr;
            foreach (string cat in category3)
            {
                dr = dt.NewRow();
                dr[0] = cat;
                dr[1] = category1;
                dr[2] = category2;
                dt.Rows.Add(dr);
            }

            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return response;
        }

        [HttpGet]
        public HttpResponseMessage GetCategory4(string id, string id1, string id2)
        {
            string category1 = id;
            string category2 = id1;
            string category3 = id2;

            BALReport BALReportObj = new BALReport();
            List<string> category4 = BALReportObj.GetCategories(category1, category2, category3);
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Category4"));
            dt.Columns.Add(new DataColumn("SelectedCategory1"));
            dt.Columns.Add(new DataColumn("SelectedCategory2"));
            dt.Columns.Add(new DataColumn("SelectedCategory3"));
            DataRow dr;
            foreach (string cat in category4)
            {
                dr = dt.NewRow();
                dr[0] = cat;
                dr[1] = category1;
                dr[2] = category2;
                dr[3] = category3;
                dt.Rows.Add(dr);
            }

            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return response;
        }

        [HttpGet]
        public HttpResponseMessage GetCategory5(string id, string id1, string id2,string id3)
        {
            string category1 = id;
            string category2 = id1;
            string category3 = id2;
            string category4 = id3;

            BALReport BALReportObj = new BALReport();
            List<string> category5 = BALReportObj.GetCategories(category1, category2, category3, category4);
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Category5"));
            dt.Columns.Add(new DataColumn("SelectedCategory1"));
            dt.Columns.Add(new DataColumn("SelectedCategory2"));
            dt.Columns.Add(new DataColumn("SelectedCategory3"));
            dt.Columns.Add(new DataColumn("SelectedCategory4"));
            DataRow dr;
            foreach (string cat in category5)
            {
                dr = dt.NewRow();
                dr[0] = cat;
                dr[1] = category1;
                dr[2] = category2;
                dr[3] = category3;
                dr[4] = category4;
                dt.Rows.Add(dr);
            }

            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return response;
        }
        [HttpGet]
        public HttpResponseMessage GetCategory6(string id, string id1, string id2, string id3,string id4)
        {
            string category1 = id;
            string category2 = id1;
            string category3 = id2;
            string category4 = id3;
            string category5 = id4;

            BALReport BALReportObj = new BALReport();
            List<string> category6 = BALReportObj.GetCategories(category1, category2, category3, category4, category5);
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Category6"));
            dt.Columns.Add(new DataColumn("SelectedCategory1"));
            dt.Columns.Add(new DataColumn("SelectedCategory2"));
            dt.Columns.Add(new DataColumn("SelectedCategory3"));
            dt.Columns.Add(new DataColumn("SelectedCategory4"));
            dt.Columns.Add(new DataColumn("SelectedCategory5"));
            DataRow dr;
            foreach (string cat in category6)
            {
                dr = dt.NewRow();
                dr[0] = cat;
                dr[1] = category1;
                dr[2] = category2;
                dr[3] = category3;
                dr[4] = category4;
                dr[5] = category5;
                dt.Rows.Add(dr);
            }

            string JSONresult;
            JSONresult = JsonConvert.SerializeObject(dt);

            string yourJson = JSONresult;
            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content = new StringContent(yourJson, Encoding.UTF8, "application/json");
            return response;
        }
    }
}
