﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using ShoppingMartUIWeb.Model;
using ShoppingMartUIWeb.ViewModel;
using ShoppingMartUIWeb.BAL;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;

namespace ShoppingMartUIWeb.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult Load(string id)
        {
            string asin = id;
            BALProduct BALProductObj = new BALProduct();
            double avg_rating = BALProductObj.get_product_avg_rating(asin);
            
            List<BsonDocument> product_list = BALProductObj.get_product_by_asin(asin);
            ProductModel PM = new ProductModel();
            PM.avg_rating = avg_rating;
            foreach (var document in product_list)
            {
                PM._id = document["_id"].AsObjectId;
                PM.asin = document["asin"].AsString;
                PM.related = document["related"].AsBsonDocument;
                PM.title = document["title"].AsString;
                PM.price = document["price"].AsDouble;
                PM.salesRank = document["salesRank"].AsBsonDocument;
                PM.imUrl = document["imUrl"].AsString;
                PM.brand = document["brand"].AsString;
                PM.categories = document["categories"].AsBsonArray;
                PM.description = document["description"].AsString;
            }
            PM.total_review_count = BALProductObj.get_total_review_count(asin);
            return View("showproduct", PM);
        }
    }
}