﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using System.Data;

using ShoppingMartUIWeb.Model;

namespace ShoppingMartUIWeb.DAL
{
    public class DALProduct
    {
        string ConnectionString = string.Empty;
        string DatabaseName;
        public DALProduct(string prmConnectionString)
        {
            ConnectionString = prmConnectionString;
            DatabaseName = "ShoppingMart";
        }

        public List<BsonDocument> get_product_by_asin(string asin)
        {
            List<BsonDocument> documents = new List<BsonDocument>();

            var client = new MongoClient(ConnectionString);
            var database = client.GetDatabase(DatabaseName);
            var collection = database.GetCollection<BsonDocument>("ProductMaster");
            var filterBuilder = Builders<BsonDocument>.Filter;

            var filter = filterBuilder.Eq("asin", asin);

            var document = collection.Find(filter).FirstOrDefault(); // get the very 1st matching document.
            if (document != null)
            {
                documents.Add(document);
            }
            client = null;
            return documents;
        }

        public int get_total_review_count(string asin)
        {
            int result = 0;
            var client = new MongoClient(ConnectionString);
            var database = client.GetDatabase(DatabaseName);
            var collection = database.GetCollection<BsonDocument>("PurchaseDetails");
            var filterBuilder = Builders<BsonDocument>.Filter;
            var filter = filterBuilder.Eq("asin", asin);
            result = (int)collection.Find(filter).Count();
            client = null;
            return result;
        }

        public DataTable get_product_review_details(string asin)
        {
            var client = new MongoClient(ConnectionString);
            var database = client.GetDatabase(DatabaseName);
            var collection = database.GetCollection<BsonDocument>("PurchaseDetails");
            var filterBuilder = Builders<BsonDocument>.Filter;
            var filter = filterBuilder.Eq("asin", asin);
            List<BsonDocument> documents = collection.Find(filter).ToList();
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("asin"));
            dt.Columns.Add(new DataColumn("overall"));
            dt.Columns.Add(new DataColumn("total"));
            foreach (var doc in documents)
            {
                DataRow dr = dt.NewRow();
                dr[0] = asin;
                dr[1] = doc["overall"];
                dr[2] = 0;
                dt.Rows.Add(dr);
            }
            DataTable dt_new = GroupBy("overall", "overall", dt);
            client = null;
            return dt_new;
        }

        public DataTable GroupBy(string i_sGroupByColumn, string i_sAggregateColumn, DataTable i_dSourceTable)
        {

            DataView dv = new DataView(i_dSourceTable);

            //getting distinct values for group column
            DataTable dtGroup = dv.ToTable(true, new string[] { i_sGroupByColumn });

            //adding column for the row count
            dtGroup.Columns.Add("Count", typeof(int));

            //looping thru distinct values for the group, counting
            foreach (DataRow dr in dtGroup.Rows)
            {
                dr["Count"] = i_dSourceTable.Compute("Count(" + i_sAggregateColumn + ")", i_sGroupByColumn + " = '" + dr[i_sGroupByColumn] + "'");
            }

            //returning grouped/counted result
            return dtGroup;
        }

        public DataTable get_product_review_all(string asin)
        {
            var client = new MongoClient(ConnectionString);
            var database = client.GetDatabase(DatabaseName);
            var collection = database.GetCollection<BsonDocument>("ProductMaster");
            var filterBuilder = Builders<BsonDocument>.Filter;
            var filter = filterBuilder.Eq("asin", asin);
            var document = collection.Find(filter).FirstOrDefault();

            BsonDocument related_doc = document["related"].AsBsonDocument;

            BsonArray also_bought = related_doc["also_bought"].AsBsonArray;

            var filter_related = filterBuilder.AnyIn("asin", also_bought);

            List<BsonDocument> documents = collection.Find(filter_related).ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("asin"));
            dt.Columns.Add(new DataColumn("title"));
            dt.Columns.Add(new DataColumn("url"));
            foreach (var doc in documents)
            {
                DataRow dr = dt.NewRow();
                dr[0] = doc["asin"].AsString;
                dr[1] = doc["title"];
                dr[2] = doc["imUrl"].AsString;
                dt.Rows.Add(dr);
            }
            client = null;
            return dt;
        }

        public double get_product_avg_rating(string asin)
        {
            DataTable dt = new DataTable();
            var client = new MongoClient(ConnectionString);
            var database = client.GetDatabase(DatabaseName);
            var collection = database.GetCollection<BsonDocument>("PurchaseDetails");
            var filterBuilder = Builders<BsonDocument>.Filter;
            var filter = filterBuilder.Eq("asin", asin);
            var documents = collection.Find(filter).ToList();
            int total_count = documents.Count();
            double sum = 0;
            foreach (var document in documents)
            {
                sum = sum + Convert.ToDouble(document["overall"].AsDouble);
            }
            double avg_rating = sum / total_count;
            client = null;
            return avg_rating;
        }

        public DataTable request_product_search(string batch_id, string search_by, string search_value)
        {
            DataTable dt = new DataTable();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<BsonDocument>("SearchDetails");
                var document = new BsonDocument
                        {
                            {"batch_id", batch_id},
                            {"search_by",search_by},
                            {"search_value",search_value},
                            {"search_response",(new BsonArray())},
                            {"process_status","ready"},
                            {"search_on",DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss")}
                        };
                collection.InsertOne(document);
                client = null;
                dt.Columns.Add(new DataColumn("Status"));
                dt.Columns.Add(new DataColumn("Message"));
                DataRow dr = dt.NewRow();
                dr[0] = "success";
                dr[1] = "success";
                dt.Rows.Add(dr);
            }
            catch (Exception ex)
            {
                dt = null;
                dt = new DataTable();
                dt.Columns.Add(new DataColumn("Status"));
                dt.Columns.Add(new DataColumn("Message"));
                DataRow dr = dt.NewRow();
                dr[0] = "Fail";
                dr[1] = ex.Message;
                dt.Rows.Add(dr);
            }
            return dt;
        }
        public BsonDocument get_search_response(string batch_id)
        {
            BsonDocument document = new BsonDocument();
            DataTable dt = new DataTable();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<BsonDocument>("SearchDetails");
                var filterBuilder = Builders<BsonDocument>.Filter;

                var filter = filterBuilder.Eq("batch_id", batch_id);

                document = collection.Find(filter).FirstOrDefault(); // get the very 1st matching document.
                client = null;
            }
            catch (Exception ex)
            {
                BsonElement BE = new BsonElement("Result", (BsonValue)"Fail");
                document.Add(BE);
                BE = new BsonElement("Message", (BsonValue)"Apologies! your session expired while getting the search results for you. Description:" + ex.Message);
                document.Add(BE);
                BE = new BsonElement("response", (BsonValue)"");
                document.Add(BE);
            }
            return document;
        }
    }
}