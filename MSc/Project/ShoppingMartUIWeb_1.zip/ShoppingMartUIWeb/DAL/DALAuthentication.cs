﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using System.Data;

using ShoppingMartUIWeb.Model;

namespace ShoppingMartUIWeb.DAL
{
    public class DALAuthentication
    {
        string ConnectionString = string.Empty;
        string DatabaseName;
        public DALAuthentication(string prmConnectionString)
        {
            ConnectionString = prmConnectionString;
            DatabaseName = "ShoppingMart";
        }

        public UserStatus Authenticate(string Email, string Password)
        {
            UserStatus Result = UserStatus.NonAuthenticatedUser;

            var client = new MongoClient(ConnectionString);
            var database = client.GetDatabase(DatabaseName);
            var collection = database.GetCollection<BsonDocument>("UserMaster");
            var filterBuilder = Builders<BsonDocument>.Filter;

            var filter = filterBuilder.Eq("Login", Email) & filterBuilder.Eq("Password", Password);

            var document = collection.Find(filter).FirstOrDefault(); // get the very 1st matching document.
            if (document != null)
            {
                var role = document["Role"].AsString;
                var collectionRole = database.GetCollection<BsonDocument>("RoleMaster");
                filter = filterBuilder.Eq("Role", role);
                var documentRole = collectionRole.Find(filter).FirstOrDefault();
                if (documentRole != null)
                {
                    var IsAdmin = documentRole["IsAdmin"].AsString;
                    if (IsAdmin == "y")
                    {
                        Result = UserStatus.AuthenticatedAdmin;
                    }
                    else
                    {
                        Result = UserStatus.AuthenticatedUser;
                    }
                }
                else
                {
                    Result = UserStatus.NonAuthenticatedUser;
                }
            }
            else
            {
                Result = UserStatus.NonAuthenticatedUser;
            }
            client = null;
            return Result;
        }
    }
}