﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using System.Data;
using ShoppingMartUIWeb.Model;

namespace ShoppingMartUIWeb.DAL
{
    public class DALReport
    {
        string ConnectionString = string.Empty;
        string DatabaseName;
        public DALReport(string prmConnectionString)
        {
            ConnectionString = prmConnectionString;
            DatabaseName = "ShoppingMart";
        }
        public DataTable updateRequest(string batch_id, string gender, string show_price, string show_related, string show_brand, BsonArray categories)
        {
            DataTable dt = new DataTable();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<BsonDocument>("RequestDetails");
                
                var document = new BsonDocument
                        {
                            {"batch_id", batch_id},
                            {"gender",gender},
                            {"show_price",show_price},
                            {"show_related",show_related},
                            {"show_brand",show_brand},
                            {"categories",categories},
                            {"request_on", DateTime.Now},
                            {"process_status","ready"},
                            {"response",""},
                            {"response_on",(new DateTime(1900,1,1))}
                        };
                collection.InsertOne(document);
                dt.Columns.Add(new DataColumn("Status"));
                dt.Columns.Add(new DataColumn("Message"));
                dt.Columns.Add(new DataColumn("batch_id"));

                DataRow dr = dt.NewRow();
                dr[0] = "Success";
                dr[1] = "Your request has been placed, please stand by while we load the products for you. You can also click on Refresh if it's taking too much time to load.";
                dr[2] = batch_id;

                dt.Rows.Add(dr);
                client = null;
            }
            catch (Exception ex)
            {
                dt = null;
                dt = new DataTable();
                dt.Columns.Add(new DataColumn("Status"));
                dt.Columns.Add(new DataColumn("Message"));
                DataRow dr = dt.NewRow();
                dr[0] = "Fail";
                dr[1] = ex.Message;
                dt.Rows.Add(dr);
            }
            return dt;
        }
        public BsonDocument getResponse(string batch_id)
        {
            BsonDocument document = new BsonDocument();
            DataTable dt = new DataTable();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<BsonDocument>("RequestDetails");
                var filterBuilder = Builders<BsonDocument>.Filter;

                var filter = filterBuilder.Eq("batch_id", batch_id);

                document = collection.Find(filter).FirstOrDefault(); // get the very 1st matching document.
                client = null;
            }
            catch (Exception ex)
            {
                BsonElement BE = new BsonElement("Result", (BsonValue)"Fail");
                document.Add(BE);
                BE = new BsonElement("Message", (BsonValue)"Apologies! your session expired while getting the recommended products for you. Description:" + ex.Message);
                document.Add(BE);
                BE = new BsonElement("response", (BsonValue)"");
                document.Add(BE);
            }
            return document;
        }

        public List<string> GetCategories()
        {
            List<string> results = new List<string>();
            try
            {
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<CategoriesMasterModel>("CategoriesMaster");
                var categories = collection.AsQueryable().Select(obj => obj.category1).Distinct();
                results = categories.ToList();
            }
            catch (Exception ex)
            {
                results.Add("Exception");
                results.Add(ex.Message);
            }
            return results;
        }

        public List<string> GetCategories(string category1)
        {
            List<string> results = new List<string>();
            try
            {
                category1 = category1.Replace("AMPERSAND", "&");
                
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<CategoriesMasterModel>("CategoriesMaster");
                var categories = collection.AsQueryable().Where(obj => obj.category1 == category1).Select(obj => obj.category2).Distinct();
                results = categories.ToList();
            }
            catch (Exception ex)
            {
                results.Add("Exception");
                results.Add(ex.Message);
            }
            return results;
        }


        public List<string> GetCategories(string category1, string category2)
        {
            List<string> results = new List<string>();
            try
            {
                category1 = category1.Replace("AMPERSAND", "&");
                category2 = category2.Replace("AMPERSAND", "&");
                
                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<CategoriesMasterModel>("CategoriesMaster");
                var categories = collection.AsQueryable().Where(obj => obj.category1 == category1 && obj.category2==category2).Select(obj => obj.category3).Distinct();
                results = categories.ToList();
            }
            catch (Exception ex)
            {
                results.Add("Exception");
                results.Add(ex.Message);
            }
            return results;
        }

        public List<string> GetCategories(string category1, string category2, string category3)
        {
            List<string> results = new List<string>();
            try
            {
                category1 = category1.Replace("AMPERSAND", "&");
                category2 = category2.Replace("AMPERSAND", "&");
                category3 = category3.Replace("AMPERSAND", "&");

                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<CategoriesMasterModel>("CategoriesMaster");
                var categories = collection.AsQueryable().Where(obj => obj.category1 == category1 && obj.category2 == category2 && obj.category3 == category3).Select(obj => obj.category4).Distinct();
                results = categories.ToList();
            }
            catch (Exception ex)
            {
                results.Add("Exception");
                results.Add(ex.Message);
            }
            return results;
        }

        public List<string> GetCategories(string category1, string category2, string category3, string category4)
        {
            List<string> results = new List<string>();
            try
            {
                category1 = category1.Replace("AMPERSAND", "&");
                category2 = category2.Replace("AMPERSAND", "&");
                category3 = category3.Replace("AMPERSAND", "&");
                category4 = category4.Replace("AMPERSAND", "&");

                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<CategoriesMasterModel>("CategoriesMaster");
                var categories = collection.AsQueryable().Where(obj => obj.category1 == category1 && obj.category2 == category2 && obj.category3 == category3 && obj.category4==category4).Select(obj => obj.category5).Distinct();
                results = categories.ToList();
            }
            catch (Exception ex)
            {
                results.Add("Exception");
                results.Add(ex.Message);
            }
            return results;
        }

        public List<string> GetCategories(string category1, string category2, string category3, string category4, string category5)
        {
            List<string> results = new List<string>();
            try
            {
                category1 = category1.Replace("AMPERSAND", "&");
                category2 = category2.Replace("AMPERSAND", "&");
                category3 = category3.Replace("AMPERSAND", "&");
                category4 = category4.Replace("AMPERSAND", "&");
                category5 = category5.Replace("AMPERSAND", "&");

                var client = new MongoClient(ConnectionString);
                var database = client.GetDatabase(DatabaseName);
                var collection = database.GetCollection<CategoriesMasterModel>("CategoriesMaster");
                var categories = collection.AsQueryable().Where(obj => obj.category1 == category1 && obj.category2 == category2 && obj.category3 == category3 && obj.category4 == category4 && obj.category5 == category5).Select(obj => obj.category6).Distinct();
                results = categories.ToList();
            }
            catch (Exception ex)
            {
                results.Add("Exception");
                results.Add(ex.Message);
            }
            return results;
        }
        
    }
}