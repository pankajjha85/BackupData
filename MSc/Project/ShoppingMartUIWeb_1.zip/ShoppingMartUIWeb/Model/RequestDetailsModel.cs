﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using System.Data;

namespace ShoppingMartUIWeb.Model
{
    public class RequestDetailsModel
    {
        public ObjectId _id { get; set; }
        public string batch_id { get; set; }
        public string gender { get; set; }
        public string show_price { get; set; }
        public string show_related { get; set; }
        public string show_brand { get; set; }
        public string categories { get; set; }
        
    }
}