﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingMartUIWeb.Model
{
    public class ReportModel
    {
        public string asin { get; set; }
        public string title { get; set; }
        public string url { get; set; }
        public double avg_rating_by_product { get; set; }
    }
}