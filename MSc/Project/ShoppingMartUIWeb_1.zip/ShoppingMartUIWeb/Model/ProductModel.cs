﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;

namespace ShoppingMartUIWeb.Model
{
    public class ProductModel
    {
        public ObjectId _id { get; set; }
        public string asin { get; set; }
        public BsonDocument related { get; set; }
        public string title { get; set; }
        public double price { get; set; }
        public BsonDocument salesRank { get; set; }
        public string imUrl { get; set; }
        public string brand { get; set; }
        public BsonArray categories { get; set; }
        public string description { get; set; }
        public double avg_rating { get; set; }
        public DataTable dt_avg_rating_details { get; set; }
        public int total_review_count { get; set; }
    }
}