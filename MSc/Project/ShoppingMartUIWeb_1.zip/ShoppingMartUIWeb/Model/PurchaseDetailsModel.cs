﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;

namespace ShoppingMartUIWeb.Model
{
    public class PurchaseDetailsModel
    {
        public ObjectId _id { get; set; }
        public string reviewerID { get; set; }
        public string asin { get; set; }
        public string reviewerName { get; set; }
        public BsonArray helpful { get; set; }
        public string reviewText { get; set; }
        public double overall { get; set; }
        public string summary { get; set; }
        public int unixReviewTime { get; set; }
        public string reviewTime { get; set; }
        public string gender { get; set; }
    }
}