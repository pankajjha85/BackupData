﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ShoppingMartUIWeb.Model
{
    public enum UserStatus
    {
        AuthenticatedAdmin,
        AuthenticatedUser,
        NonAuthenticatedUser
    }
}