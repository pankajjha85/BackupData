﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDB.Driver.Linq;

namespace ShoppingMartUIWeb.Model
{
    public class CategoriesMasterModel
    {
        public ObjectId _id { get; set; }
        public string category1 { get; set; }
        public string category2 { get; set; }
        public string category3 { get; set; }
        public string category4 { get; set; }
        public string category5 { get; set; }
        public string category6 { get; set; }
    }
}