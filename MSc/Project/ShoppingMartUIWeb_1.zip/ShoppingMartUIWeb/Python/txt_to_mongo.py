# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 13:43:33 2017

@author: pankaj_j
"""
import sys
import pandas as pd
from time import gmtime,strftime

def initiatemongodbconnection(DBS_NAME):
#{
    """
    A function to initiate connection with a Mongodb database .
    accepts DB name as a parameter
    """
    import pymongo    
    from pymongo import MongoClient
    conn=pymongo.MongoClient()
    db=conn[DBS_NAME]    
    
    return db
#}

DBS_NAME='ShoppingMart'
db=initiatemongodbconnection(DBS_NAME)        # get the db object

CitizensMasterCollection=db['CitizensNameMaster']
PurchaseDetailsCollection=db['PurchaseDetails']
ProductMasterCollection=db['ProductMaster']
PurchaseSummaryByGenderCollection=db['PurchaseSummaryByGender']
RequestDetailsCollection=db['RequestDetails']
SearchDetailsCollection=db['SearchDetails']
CategoriesMasterCollection=db['CategoriesMaster']

def create_category_master():
#{
    df_products = ProductMasterCollection.find({})
    i=1
    for d in df_products:
    #{
        categories_list = d['categories']
        for categories in categories_list:
        #{
            i=1
            dictionary={}
            for each_category in categories:
            #{
                dictionary['category'+str(i)] = each_category
                #print('category'+str(i)+':'+each_category)
                i = i + 1
            #}
            
            df_category = CategoriesMasterCollection.find(dictionary)
            if df_category.count()==0:
            #{
                CategoriesMasterCollection.insert_one(dictionary)
            #}        
        #}
    #}
#}




def txt_to_mongo():
#{
   lst=range(1880,2011)
   for index in lst:
   #{
     text_file = open("D:\\Pankaj\\Others\\Personal\\MSc\\Part-2\\Project\\genderPredictor-master\\names\\yob"+ str(index) +".txt", "r")
     lines = text_file.read().split('\n')
     for line in lines:
     #{
         if(len(line)>0):
            data=line.split(',')
            db.get_collection("CitizensNameMaster").insert_one({"name":data[0],"gender":data[1],"counts":data[2]})
     #}
        
   #}
     
#}

pipe=[{"$group" : {"_id" : {"name":"$name", "gender":"$gender"}}},{"$project" : {"_id":0, "name":"$_id.name", "gender":"$_id.gender"}}]

#df=PurchaseDetailsCollection.find({"reviewerID":"abc"})
i=0

d=CitizensMasterCollection.aggregate(pipeline = pipe)

def Export_distinct_names_to_DF():
#{
    i=0
    newDF = pd.DataFrame()
    for d1 in d:
    #{
        if i>=0:
        #{
            newDF.loc[i,"name"]=d1['name']
            newDF.loc[i,"gender"]=d1['gender']
            print(i)
        #}
        else:
        #{
            break
        #}
        i=i+1
    #}

#}

def updateGenderInPurchaseDetails():
#{
    df_purchase = pd.DataFrame()
    
    for citizen in d:
    #{
        print(citizen)
        if i>=0:
        #{
            df_purchase=PurchaseDetailsCollection.find({"reviewerName":{"$regex":citizen["name"]}})
            for each_purchase in df_purchase:
            #{
                object_id=each_purchase['_id']
                cust_name_list=each_purchase['reviewerName'].split(' ')
                if len(cust_name_list)==1: # if there is only one word, chances are high that it will match the citizen master name
                #{
                    if cust_name_list[0].lower()==citizen["name"].lower():   # check for exact matching, if true, update the gender.
                    #{
                        PurchaseDetailsCollection.update_many({"_id":object_id},{"$set":{"gender":citizen["gender"]}})
                    #}
                #}
                else:
                #{
                    if cust_name_list[0].lower()==citizen["name"].lower():   # if first word is matching with name in citizen master
                    #{
                        PurchaseDetailsCollection.update_many({"_id":object_id},{"$set":{"gender":citizen["gender"]}})
                    #}
                    else:
                    #{
                        if cust_name_list[1].lower()==citizen["name"].lower():  # check if 2nd word is matching with citizen master name, then update the gender else skip
                        #{
                            PurchaseDetailsCollection.update_many({"_id":object_id},{"$set":{"gender":citizen["gender"]}})
                        #}
                    #}
                #}
            #}
            #PurchaseDetailsCollection.update_many({"reviewerName":{"$regex":citizen["name"]}},{"$set":{"gender":citizen["gender"]}})
        #}
        else:
        #{
            break
        #}
        i=i+1
    #}
#}

def get_avg_rating_by_gender(gender):
#{
    df_purchase = pd.DataFrame()
    df_purchase=PurchaseDetailsCollection.find({"gender":gender})
    ratings = []
    
    for review in df_purchase:
      ratings.append(review['overall'])
    
    denominator=1
    if len(ratings)>0:
    #{
        denominator = len(ratings)
    #}
    avg_rating = sum(ratings) / denominator
    return avg_rating,denominator
#}

def get_avg_rating_by_product(product_id):
#{
    df_purchase = pd.DataFrame()
    df_purchase = PurchaseDetailsCollection.find({"asin":product_id})
    ratings = []
    
    for review in df_purchase:
      ratings.append(review['overall'])
    
    denominator=1
    if len(ratings)>0:
    #{
        denominator = len(ratings)
    #}
    avg_rating = sum(ratings) / denominator
    return avg_rating
#}

    
#a,d=get_avg_rating('F')
#print(a)
#print(d)

def get_and_update_purchase_summary(gender):
#{
    df_purchase_summary=PurchaseSummaryByGenderCollection.find({"gender":gender})
    len_rating=0
    threshold_calc=0.0
    avg_rating=0.0
    for d in df_purchase_summary:
    #{
        len_rating=d['len_rating']
        threshold_calc=d['threshold_calc']
        avg_rating=d['avg_rating']
    #}
    new_count=PurchaseDetailsCollection.find({"gender":gender}).count()
    if new_count > (len_rating + (len_rating*threshold_calc)):
    #{
        avg_rating,len_rating = get_avg_rating_by_gender(gender)
        PurchaseSummaryByGenderCollection.update({"gender":gender} , {"$set": {"$and": [ {"avg_rating":avg_rating}, {"len_rating":len_rating} ] } })
    #}
    
    return avg_rating
#}

lst_items=[]
list_product_id=[]
def get_recommended_items():
#{
    df_request_details = RequestDetailsCollection.find( {"process_status":"ready"} )
    batch_id=''
    gender=''
    show_price=''
    show_related=''
    show_brand=''
    categories=[]

    for d in df_request_details:
    #{
        batch_id = d['batch_id']
        gender = d['gender']
        show_price = d['show_price']
        show_related = d['show_related']
        show_brand = d['show_brand']
        categories = d['categories']
    #}    
    
    if len(batch_id) > 0:
    #{
        
        RequestDetailsCollection.update({ "$and": [ {"batch_id":batch_id}, {"process_status":"ready"} ] }, {"$set": {"process_status":"pending"} })
        
        avg_rating = get_and_update_purchase_summary(gender)    
        #print(avg_rating)
        
        
        df_products=pd.DataFrame()
        
        
        """
        # if show_brand='all', then remove the brand filter
        if show_brand=='all':
        #{
            df_products=ProductMasterCollection.find({ "$and": [ {"title":{"$exists":"true"}}, {"price":{"$exists":show_price}} , {"related":{"$exists":show_related}}  ] })
        #}
        else:
        #{
            df_products=ProductMasterCollection.find({ "$and": [ {"title":{"$exists":"true"}}, {"price":{"$exists":show_price}} , {"related":{"$exists":show_related}} , {"brand":{"$exists":show_brand}} ] })
        #}
        """
        print(len(categories))
        if len(categories) == 1:
        #{
            df_products=ProductMasterCollection.find({ "$and": [ {"title":{"$exists":"true"}}, {"price":{"$exists":show_price}} , {"related":{"$exists":show_related}}  ] })
        #}
        elif len(categories) == 2:
        #{
            pipe = [{'$unwind': '$categories'}, {'$match': {"categories": {'$in': [categories[0]]}}}]
            df_products=ProductMasterCollection.aggregate( pipeline=pipe )
        #}
        elif len(categories) == 3:
        #{
            pipe=[{'$unwind': '$categories'}, {'$match': {"categories": {'$in': [categories[0]]}}}, {'$match': {"categories": {'$in': [categories[1]]}}}]
            df_products=ProductMasterCollection.aggregate( pipeline=pipe )
        #}
        elif len(categories) == 4:
        #{
            pipe = [{'$unwind': '$categories'}, {'$match': {"categories": {'$in': [categories[0]]}}}, {'$match': {"categories": {'$in': [categories[1]]}}}, {'$match': {"categories": {'$in': [categories[2]]}}}]
            df_products=ProductMasterCollection.aggregate( pipeline=pipe )
        #}
        elif len(categories) == 5:
        #{
            pipe = [{'$unwind': '$categories'}, {'$match': {"categories": {'$in': [categories[0]]}}}, {'$match': {"categories": {'$in': [categories[1]]}}}, {'$match': {"categories": {'$in': [categories[2]]}}}, {'$match': {"categories": {'$in': [categories[3]]}}}]
            df_products=ProductMasterCollection.aggregate( pipeline=pipe )
        #}
        elif len(categories) == 6:
        #{
            pipe = [{'$unwind': '$categories'}, {'$match': {"categories": {'$in': [categories[0]]}}}, {'$match': {"categories": {'$in': [categories[1]]}}}, {'$match': {"categories": {'$in': [categories[2]]}}}, {'$match': {"categories": {'$in': [categories[3]]}}},{'$match': {"categories": {'$in': [categories[4]]}}}]
            df_products=ProductMasterCollection.aggregate( pipeline=pipe )
        #}
        
        '''
        else if categories.length==2:
        #{
            if categories[1]=='all':
        #}
        '''
       
        
        dict_products_with_title={}
        dict_products_with_url={}
        for product in df_products:
        #{
            
            try:
            #{
               title=product['title']
               list_product_id.append(product['asin'])
               dict_products_with_title[product['asin']]=product['title']
               dict_products_with_url[product['asin']]=product['imUrl']
            #}
            except:
            #{
               # do nothing
               title=''
            #}
        #}
        
        #print(sum(ratings))
        #print(len(ratings))
        
        avg_rating_by_product=0.0
        
        df_purchase_good_rating=pd.DataFrame()
        df_purchase_good_rating=PurchaseDetailsCollection.find({"$and":[ {"gender":gender},{"overall":{"$gte":int(avg_rating)}}, {"asin":{"$in":list_product_id}} ]})
        
        response=[]
        
        for d in df_purchase_good_rating.limit(15):
        #{
            if lst_items.count(d['asin'])==0:
            #{
                lst_items.append(d['asin'])
                avg_rating_by_product = get_avg_rating_by_product(d['asin'])
                #response = response + d['asin']+'~'+ dict_products_with_title[d['asin']]+'~'+ dict_products_with_url[d['asin']]+'~'+str(avg_rating_by_product)+'|'
                response.append( [ d['asin'],dict_products_with_title[d['asin']],dict_products_with_url[d['asin']],str(avg_rating_by_product) ])
                print(response)
            #}
        #}
        if len(response) > 0:
        #{
            response_on = strftime('%Y-%m-%d %H-%M-%S')
            RequestDetailsCollection.update( {"batch_id":batch_id} , {"$set": {"process_status":"processed", "response":response, "response_on":response_on} })
            print(response)
        #}
    #}
    else:
    #{
        print('no request found')
    #}
#}

def search_product_by_title():
#{
    df_search = SearchDetailsCollection.find({"process_status":"ready"})
    if df_search.count() > 0:
    #{
        for each_search in df_search:
        #{
            batch_id = each_search['batch_id']
            search_by = each_search['search_by']
            search_value = each_search['search_value']
            
            if len(batch_id) > 0 and len(search_by) > 0 and len(search_value) > 0:
            #{
                df_products = ProductMasterCollection.find({ search_by : { "$regex" : search_value } })
                search_response = []
                for each_product in df_products:
                #{
                    search_response.append( [ each_product['asin'] , each_product['title'] , each_product['imUrl'] ] )
                #}
                    
                if len(search_response) > 0:
                #{
                    SearchDetailsCollection.update_many({ "batch_id" : batch_id }, { "$set" : {"search_response" : search_response , "process_status" : "processed" } } )
                #}
            #}        
        #}

    #}
#}

function_name = sys.argv[1]
if function_name == 'get_recommended_items':
#{
    get_recommended_items()
#}

if function_name == 'search_product_by_title':
#{
    search_product_by_title()
#}