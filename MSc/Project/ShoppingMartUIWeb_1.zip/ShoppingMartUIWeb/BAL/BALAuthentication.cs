﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson;
using System.Data;
using System.Configuration;

using ShoppingMartUIWeb.DAL;
using ShoppingMartUIWeb.Model;

namespace ShoppingMartUIWeb.BAL
{
    public class BALAuthentication
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        DALAuthentication DALAuthenticationObj;

        public BALAuthentication()
        {
            DALAuthenticationObj = new DALAuthentication(ConnectionString);
        }
        public UserStatus Authenticate(string Email, string Password)
        {
            return DALAuthenticationObj.Authenticate(Email, Password);
        }
    }


}