﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson;
using System.Data;
using System.Configuration;
using ShoppingMartUIWeb.DAL;

namespace ShoppingMartUIWeb.BAL
{
    public class BALReport
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        DALReport DALReportObj;

        public BALReport()
        {
            DALReportObj = new DALReport(ConnectionString);
        }

        public DataTable updateRequest(string batch_id, string gender, string show_price, string show_related, string show_brand, string category)
        {
            BsonArray categories = new BsonArray();

            foreach (var each_category in category.Split(','))
            {
                categories.Add((BsonValue)each_category.Replace("AMPERSAND", "&"));
            }

            return DALReportObj.updateRequest(batch_id, gender, show_price, show_related, show_brand, categories);
        }
        public BsonDocument getResponse(string batch_id)
        {
            return DALReportObj.getResponse(batch_id);
        }

        public List<string> GetCategories()
        {
            return DALReportObj.GetCategories();
        }

        public List<string> GetCategories(string category1)
        {
            return DALReportObj.GetCategories(category1);
        }

        public List<string> GetCategories(string category1, string category2)
        {
            return DALReportObj.GetCategories(category1, category2);
        }

        public List<string> GetCategories(string category1, string category2, string category3)
        {
            return DALReportObj.GetCategories(category1, category2, category3);
        }

        public List<string> GetCategories(string category1, string category2, string category3, string category4)
        {
            return DALReportObj.GetCategories(category1, category2, category3, category4);
        }

        public List<string> GetCategories(string category1, string category2, string category3, string category4, string category5)
        {
            return DALReportObj.GetCategories(category1, category2, category3, category4, category5);
        }
    }
}