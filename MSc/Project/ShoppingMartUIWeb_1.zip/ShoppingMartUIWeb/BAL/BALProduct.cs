﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Bson;
using System.Data;
using System.Configuration;
using ShoppingMartUIWeb.DAL;

namespace ShoppingMartUIWeb.BAL
{
    public class BALProduct
    {
        string ConnectionString = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        DALProduct DALProductObj;

        public BALProduct()
        {
            DALProductObj = new DALProduct(ConnectionString);
        }
        public List<BsonDocument> get_product_by_asin(string asin)
        {
            return DALProductObj.get_product_by_asin(asin);
        }

        public DataTable get_product_review_details(string asin)
        {
            return DALProductObj.get_product_review_details(asin);
        }

        public int get_total_review_count(string asin)
        {
            return DALProductObj.get_total_review_count(asin);
        }

        public DataTable get_product_review_all(string asin)
        {
            return DALProductObj.get_product_review_all(asin);
        }

        public double get_product_avg_rating(string asin)
        {
            return DALProductObj.get_product_avg_rating(asin);
        }

        public DataTable request_product_search(string batch_id, string search_by, string search_value)
        {
            return DALProductObj.request_product_search(batch_id, search_by, search_value);
        }

        public BsonDocument get_search_response(string batch_id)
        {
            return DALProductObj.get_search_response(batch_id);
        }
    }
}