﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ShoppingMartUIWeb.Startup))]
namespace ShoppingMartUIWeb
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
