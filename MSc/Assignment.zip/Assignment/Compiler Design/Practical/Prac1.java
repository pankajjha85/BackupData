import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

class Prac1
{
	public static void main(String ar[])
	{
		String[][] Productions={
			{"A","a","B"},
			{"B","b","A"},
			{"A","b","C"},
			{"C","a","A"},
			{"C","a","B"}
		};

		String[][] NDFA ;
	
		String[] Terminals;
		String[] NonTerminals;
		
		String temp = "";
		
		
		int i,j,k;
		
		for(i=0;i<5;i++)
		{
			if(temp.indexOf(Productions[i][1]) == -1)
			{
				temp = temp + Productions[i][1];
			}
		}
		
		System.out.println("The Productions are:");
		for(i=0 ; i<5 ; i++)
		{
			for(j=0 ; j<3 ; j++)
			{
				if(j==1)
				{
					System.out.print("->");
				}
				System.out.print(Productions[i][j]);
			}
			System.out.println();
		}
		
		// **** Print Terminals  ******
		int Terminals_Length = temp.length();
		Terminals = new String[Terminals_Length];
		for(i = 0; i < Terminals_Length; i++ )
		{
			Terminals[i] = temp.substring(i, i+1);
			System.out.println("Terminals: "+ Terminals[i]);
		}
		
		temp = "";
		
		for(i=0;i<5;i++)
		{
			if(temp.indexOf(Productions[i][0]) == -1)
			{
				temp = temp + Productions[i][0];
			}
		}
		
		// ***** Print NonTerminals  *******
		int NonTerminals_Length = temp.length();
		NonTerminals = new String[NonTerminals_Length];
		for(i = 0; i < NonTerminals_Length; i++ )
		{
			NonTerminals[i] = temp.substring(i, i+1);
			System.out.println("NonTerminals: "+ NonTerminals[i]);
		}
		
		// **** Initialize the NDFA with Terminals and NonTerminals ***
		NDFA = new String[NonTerminals_Length+1][Terminals_Length+1];
		for(i=0 ; i<NonTerminals_Length+1 ; i++)
		{
			if(i==0)
			{
				NDFA[i][0]="";
				
				for(j=1 ; j<Terminals_Length+1 ; j++ )
				{
					NDFA[i][j] = Terminals[j-1];
				}
			}
			else
			{
				NDFA[i][0] = NonTerminals[i-1];
				for(j=1 ; j<Terminals_Length+1 ; j++ )
				{
					NDFA[i][j] = "0";
				}
			}
		}
		
		/*
		System.out.println("Initial NDFA:");
		for(i=0 ; i<NonTerminals_Length+1 ; i++)
		{
			for(j=0 ; j<Terminals_Length+1 ; j++ )
			{
				System.out.print(NDFA[i][j] +"\t");
			}
			System.out.println();
		}
		*/
		
		/* Calculate and Update NDFA metric */
		for(i=1 ; i<NonTerminals_Length+1 ; i++)
		{
			for(j=1 ; j<Terminals_Length+1 ; j++ )
			{
				for(k=0 ; k<5 ; k++)
				{
					if(Productions[k][0].equals(NDFA[i][0]) && Productions[k][1].equals(NDFA[0][j]))
					{
						if( NDFA[i][j] == "0")
						{
							NDFA[i][j] = "";
						}
						NDFA[i][j] = NDFA[i][j] + Productions[k][2];
					}
				}
			}
		}
		
		System.out.println("\nNDFA Metric:");
		for(i=0 ; i<NonTerminals_Length+1 ; i++)
		{
			if(i==1)
			{
				System.out.println("---------------------");
			}
			for(j=0 ; j<Terminals_Length+1 ; j++ )
			{
				System.out.print(NDFA[i][j] +"\t");
			}
			System.out.println();
		}
		
		// *** Set the values in the First row of DFA metric  ****
		String[][] DFA = new String[20][Terminals_Length+1];
		for(j=0 ; j<Terminals_Length+1 ; j++)
		{
			if(j==0)
			{
				DFA[0][j] = "";
			}
			else
			{
				DFA[0][j] = Terminals[j-1];
			}
			DFA[1][j] = NDFA[1][j];
		}
		
		// *** Initially set "" to all the remaining positions in DFA metric
		for(i=2 ; i<20 ; i++)
		{
			for(j=0 ; j<Terminals_Length+1 ; j++)
			{
				DFA[i][j] = "";
			}
		}
		
		int Processed_NonTerminals_Length=0;
		int DoProcessing=0;
		int Start_Index=0;
		int i1=0;
		int j1=0;
		temp="";
		// *** Start processing from 2nd row ******
		for(i=1 ; i<20 ; i++)
		{
			DoProcessing=0;
			for( j=1 ; j<Terminals_Length+1 ; j++ )	// Loop for iterating through the NonTerminals below the Terminals in DFA metric
			{
				// Loop through the first column of DFA metric to check if the NonTerminal we are planning to process already exists or not. 
				// If not exists then go ahead with the processing, else skip it.
				for(i1=1 ; i1<20 ; i1++)   
				{
					if( DFA[i1][0].equals(DFA[i][j]) )
					{
						DoProcessing=0;
						break;
					}
					else if( DFA[i1][0].equals("") )
					{
						DFA[i1][0] = DFA[i][j];
						DoProcessing=1;
						break;
					}
				}
				
				// Check the flag if processing is required.
				if( DoProcessing==1 )
				{
					// If we got a NonTerminals like 'AB' or 'ABC', then process it for each NonTerminal.
					for( Start_Index=0 ; Start_Index<DFA[i][j].length() ; Start_Index++ )
					{
						temp = DFA[i][j].substring( Start_Index , Start_Index+1 );
						
						// This loop will iterate through the Terminals (a,b)
						for(j1=1 ; j1<Terminals_Length+1 ; j1++ )
						{
							// This loop will iterate through the Productions one by one to check the edges and assign it to the appropriate positions in DFA.
							for(k=0 ; k<5 ; k++)
							{
								if(Productions[k][0].equals(temp) && Productions[k][1].equals(DFA[0][j1]))
								{
									if( DFA[i1][j1].indexOf(Productions[k][2])==-1 )
									{
										DFA[i1][j1] = DFA[i1][j1] + Productions[k][2];
									}
								}
							}
						}
					}	
				}
			}
		}
		
		
		
		
		System.out.println("\nDFA Metric:");
		for(i=0 ; i<20; i++)
		{	
			if(i==1)
			{
				System.out.println("---------------------");
			}
			if( DFA[i][0].equals("") && i>0 )
			{
				break;
			}
			else
			{
				for(j=0 ; j<Terminals_Length+1 ; j++)
				{
					System.out.print(DFA[i][j] +"\t");
				}
				System.out.println();
			}
		}
	}
}