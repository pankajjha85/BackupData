class Prac3
{
	public static void main(String args[])
	{
		int i, j, k;
		int max_size=7;
		int I[][] = new int[7][7];
		int B[][]={
				{0,1,0,0,0,0,0}, 
				{0,0,0,0,0,0,0}, 
				{0,0,0,0,1,1,0},
				{0,0,1,0,0,0,0}, 
				{0,0,0,0,0,0,0}, 
				{0,0,0,0,0,0,0},
				{0,0,0,0,0,0,0} };

		for(i=0;i<max_size;i++)
		{
			for(j=0;j<max_size;j++)
			{
				if(i == j)
				{
					I[i][j] = 1;
				}
				else
				{
					I[i][j] = 0;
				}
			}
		}

		System.out.println("\nB matrix:");

		for(i=0; i<max_size; i++)
		{
			for(j=0; j<max_size; j++)
			{
				System.out.print(B[i][j] +" ");
			}
			System.out.println();
		}

		int A[][]=new int[7][7];
		A = B;

		
		for(i=0; i<max_size; i++)
		{
			for(j=0; j<max_size; j++)
			{
				if( A[j][i] == 1 )
				{
					for(k=0; k<max_size; k++)
					{
						A[j][k] = A[j][k] | A[i][k] ;
					}
				}
			}
		}

		System.out.println("\nB+ matrix:");

		for(i=0; i<7; i++)
		{
			for(j=0; j<7; j++)
			{
				System.out.print(A[i][j] +" ");
			}
			System.out.println();
		}

		for(i=0;i<max_size;i++)
		{
			for(j=0;j<max_size;j++)
			{
				A[i][j] = A[i][j] + I[i][j];
			}
		}

		System.out.println("\nIdentity matrix:");

		for(i=0; i<max_size; i++)
		{
			for(j=0; j<max_size; j++)
			{
				System.out.print(I[i][j] +" ");
			}
			System.out.println();
		}

		System.out.println("\nB* matrix:");
		for(i=0; i<7; i++)
		{
			for(j=0; j<7; j++)
			{
				System.out.print(A[i][j] +" ");
			}
			System.out.println();
		}

	}
}