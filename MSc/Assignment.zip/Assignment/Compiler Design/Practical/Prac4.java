class Prac4
{
	public static void main(String a[])
	{
		String[][] Productions={
			{"Z","b","M","b"},
			{"M","(","L"," "},
			{"M","a"," "," "},
			{"L","M","a",")"}
		};
		
		boolean AreGrammarsCorrect=true;
		int i=0 , j=0 , k=0;
		
		for( i=0; i<4 ; i++ )
		{
			if( Productions[i][0].equals("") || Productions[i][1].equals("") )
			{
				AreGrammarsCorrect=false;
				break;
			}
		}
		
		if( AreGrammarsCorrect==false )
		{
			System.out.println("One or more Grammars are not in correct format, hence cannot process further.");
		}
		else
		{
			String StrTemp="";
			String AllChars="";
			String[][] FIRST;
			String[][] FIRSTPlus;
			String[][] FIRSTStar;
			int[][] Identity;
			String[][] LAST;
			String[][] LASTPlus;
			String[][] LASTStar;
			String[][] EQUAL;
			String[][] LESSThan;
			
			for( i=0; i<4; i++ )
			{
				for( j=0; j<4; j++ )
				{
					if( StrTemp.indexOf(Productions[i][j]) == -1 )
					{
						if( Productions[i][j].equals(" ") == false )
						{
							StrTemp = StrTemp + Productions[i][j];
						}
					}
				}
			}
			
			AllChars = StrTemp;
			char[] AllCharsArray = AllChars.toCharArray();
			FIRST = new String[AllChars.length()+1][AllChars.length()+1];
			FIRSTPlus = new String[AllChars.length()+1][AllChars.length()+1];
			FIRSTStar = new String[AllChars.length()+1][AllChars.length()+1];
			Identity =  new int[AllChars.length()][AllChars.length()];
			LAST = new String[AllChars.length()+1][AllChars.length()+1];
			LASTPlus = new String[AllChars.length()+1][AllChars.length()+1];
			LASTStar = new String[AllChars.length()+1][AllChars.length()+1];
			EQUAL = new String[AllChars.length()+1][AllChars.length()+1];
			LESSThan = new String[AllChars.length()+1][AllChars.length()+1];
			
			// *** Initialize the metrics with blank values.
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					if( i>0 )
					{
						FIRST[i][j] = "0";
						FIRSTPlus[i][j] = "0";
						FIRSTStar[i][j] = "0";
						LAST[i][j] = "0";
						LASTPlus[i][j] = "0";
						LASTStar[i][j] = "0";
						EQUAL[i][j] = "0";
						LESSThan[i][j] = "0";
					}
					else
					{
						FIRST[i][j] = "";
						FIRSTPlus[i][j] = "";
						FIRSTStar[i][j] = "";
						LAST[i][j] = "";
						LASTPlus[i][j] = "";
						LASTStar[i][j] = "";
						EQUAL[i][j] = "";
						LESSThan[i][j] = "";
					}
				}
			}
			
			// *** Initialize the Identity metric
			for( i=0; i<AllChars.length(); i++ )
			{
				for( j=0; j<AllChars.length(); j++ )
				{
					if( i==j )
					{
						Identity[i][j] = 1;
					}
					else
					{
						Identity[i][j] = 0;
					}
				}
			}
			
			// *** Fill the 1st row and 1st column with unique characters in the Productions
			for( i=1; i<AllChars.length()+1; i++ )
			{
				FIRST[0][i] = AllCharsArray[i-1]+"";
				FIRST[i][0] = AllCharsArray[i-1]+"";
				
				FIRSTPlus[0][i] = AllCharsArray[i-1]+"";
				FIRSTPlus[i][0] = AllCharsArray[i-1]+"";
				
				FIRSTStar[0][i] = AllCharsArray[i-1]+"";
				FIRSTStar[i][0] = AllCharsArray[i-1]+"";
				
				LAST[0][i] = AllCharsArray[i-1]+"";
				LAST[i][0] = AllCharsArray[i-1]+"";
				
				LASTPlus[0][i] = AllCharsArray[i-1]+"";
				LASTStar[i][0] = AllCharsArray[i-1]+"";
				
				EQUAL[0][i] = AllCharsArray[i-1]+"";
				EQUAL[i][0] = AllCharsArray[i-1]+"";
				
				LESSThan[0][i] = AllCharsArray[i-1]+"";
				LESSThan[i][0] = AllCharsArray[i-1]+"";
			}
			
			
			
			
			
			// *** Compute FIRST metric
			for( k=0; k<4; k++ )
			{
				for( i=1; i<AllChars.length()+1; i++ )
				{
					if( Productions[k][0].equals(FIRST[i][0]) )
					{
						for( j=1; j<AllChars.length()+1; j++ )
						{
							if( Productions[k][1].equals(FIRST[0][j]) )
							{
								if( FIRST[i][j].equals("1") == false )
								{
									FIRST[i][j] = "1";
									
								}
							}
							else
							{
								if( FIRST[i][j].equals("1") == false )
								{
									FIRST[i][j] = "0";
								}
							}
							FIRSTPlus[i][j] = FIRST[i][j];
						}
					}
				}
			}
			
			
			
			
			// *** Compute FIRSTPlus metric
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					if( FIRST[j][i].equals("1") )
					{
						for( k=0; k<AllChars.length()+1; k++ )
						{
							if( FIRST[j][i].equals("1") && FIRST[i][k].equals("1") )
							{
								FIRSTPlus[j][k] = "1";
							}
						}
					}
					FIRSTStar[i][j] = FIRSTPlus[i][j];
				}
			}
			
			
			
			
			
			// *** Compute FIRSTStar metric by adding Identity metric to it.
			for( i=1; i<AllChars.length()+1; i++ )
			{
				for( j=1; j<AllChars.length()+1; j++ )
				{
					FIRSTStar[i][j] = (Integer.parseInt(FIRSTStar[i][j]) + Identity[i-1][j-1]) +"";
				}
			}
			
			
			
			
			// *** Compute LAST metric ******
			int m=0;
			boolean LookNextGrammar=false;			
			for( k=0; k<4; k++ )
			{
				LookNextGrammar=false;
				for( i=1; i<AllChars.length()+1; i++ )
				{
					if( Productions[k][0].equals(LAST[i][0]) )
					{
						for( m=3 ; m>0 ; m-- )
						{
							for( j=1; j<AllChars.length()+1; j++ )
							{	
								if( Productions[k][m].equals(" ")==false )
								{
									if( Productions[k][m].equals(LAST[0][j]) )
									{
										//if( LAST[i][j].equals("1") == false )
										//{
											LAST[i][j] = "1";
											LookNextGrammar=true;
											break;
										//}
									}
									else
									{
										/* if( LAST[i][j].equals("1") == false )
										{
											LAST[i][j] = "0";
										} */
										LookNextGrammar=false;
									}
								}
							}
							if( LookNextGrammar )
							{
								break;
							}
						}
						if( LookNextGrammar )
						{
							break;
						}
					}
				}
			}
			
			LASTPlus = LAST;
			
			
			
			
			// *** Compute LASTPlus metric
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					if( LAST[j][i].equals("1") )
					{
						for( k=0; k<AllChars.length()+1; k++ )
						{
							if( LAST[j][i].equals("1") && LAST[i][k].equals("1") )
							{
								LASTPlus[j][k] = "1";
							}
						}
					}
					LASTStar[i][j] = LASTPlus[i][j];
				}
			}
			
			
			
			// *** Compute LASTStar metric by adding Identity metric to it.
			for( i=1; i<AllChars.length()+1; i++ )
			{
				for( j=1; j<AllChars.length()+1; j++ )
				{
					LASTStar[i][j] = (Integer.parseInt(LASTStar[i][j]) + Identity[i-1][j-1]) +"";
				}
			}
			
			
			LookNextGrammar=false;
			for( k=0; k<4; k++ )
			{				
				for( m=1; m<4; m++ )
				{
					if( m==3 || Productions[k][m+1].equals(" ") )
					{
						break;
					}
					else
					{
						LookNextGrammar=false;
						for( i=1; i<AllChars.length()+1; i++ )
						{
							if( EQUAL[i][0].equals(Productions[k][m]) )
							{
								for( j=1; j<AllChars.length()+1; j++ )
								{
									if( EQUAL[0][j].equals(Productions[k][m+1]) )
									{
										EQUAL[i][j] = "1";
										LookNextGrammar = true;
										break;
									}
									else
									{
										LookNextGrammar = false;
									}
								}
								if( LookNextGrammar )
								{
									break;
								}
							}
						}
					}
				}
			}
			
			
			
			// *****    Compute LESSThan metric: FIRSTPlus x EQUAL     ************************
			
			
			
			// ******    Print all the above metrics   *******************************
			/*
			System.out.println("The FIRST metric values are:");
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					System.out.print(FIRST[i][j] +"\t");
				}
				System.out.println("");
			}
			*/
			System.out.println("The FIRSTPlus metric values are:");
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					System.out.print(FIRSTPlus[i][j] +"\t");
				}
				System.out.println("");
			}
			
			/*
			System.out.println("The FIRSTStar metric values are:");
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					System.out.print(FIRSTStar[i][j] +"\t");
				}
				System.out.println("");
			}
			*/
			
			/*
			System.out.println("The LAST metric values are:");
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					System.out.print(LAST[i][j] +"\t");
				}
				System.out.println("");
			}
			
			System.out.println("The LASTPlus metric values are:");
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					System.out.print(LASTPlus[i][j] +"\t");
				}
				System.out.println("");
			}
			
			System.out.println("The LASTStar metric values are:");
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					System.out.print(LASTStar[i][j] +"\t");
				}
				System.out.println("");
			}
			*/
			
			System.out.println("The EQUAL metric values are:");
			for( i=0; i<AllChars.length()+1; i++ )
			{
				for( j=0; j<AllChars.length()+1; j++ )
				{
					System.out.print(EQUAL[i][j] +"\t");
				}
				System.out.println("");
			}
		}
	}
}