class Prac2_2
{
	public static void main(String arg[])
	{
		String PostFix = "dabc++*"; // "ab+c*";
		String InFix = "";
		String StrTemp = "";
		
		String[] Stack;
		
		int i=0;
		int j=0;
		int PostFix_Length = PostFix.length();
		
		Stack = new String[PostFix_Length];
		
		char c=' ';
		
		// *****    Initialize the Stack with blank spaces    *****************
		for( i=0 ; i<PostFix_Length ; i++ )
		{
			Stack[i] = "";
		}
		
		for( i=0 ; i<PostFix_Length ; i++ )
		{
			StrTemp = "";
			c = PostFix.charAt(i);
			if( c != '+' && c != '-' && c != '*' && c != '/' )
			{
				Stack[j] = c +"";
				j++;
			}
			else
			{
				j--;
				StrTemp = "(" + Stack[j];
				Stack[j] = "";
				StrTemp = StrTemp + c;
				j--;
				StrTemp = StrTemp + Stack[j] + ")";
				
				Stack[j] = StrTemp;
				j++;
			}
			
		}
		
		InFix = StrTemp;
		
		System.out.println("PostFix Expression is:" + PostFix);
		System.out.println("");
		System.out.println("It's InFix Expression is:" + InFix);
	}
}