class Prac2_1
{
	public static void main(String args[])
	{
		String InFix = "d*(a+b+c)";	     // "a*(b-c)+d*e";
		String PostFix="";
		char[] Stack;
		
		int i=0;
		int j=0;
		int InFix_Length = InFix.length();
		
		Stack = new char[InFix_Length];
		
		char c=' ';
		
		// *****    Initialize the Stack with blank spaces    *****************
		for( i=0 ; i<InFix_Length ; i++ )
		{
			Stack[i] = ' ';
		}
		
		for( i=0 ; i<InFix_Length ; i++)
		{
			c = InFix.charAt(i);
			if( c == '+' || c == '-' || c == '*' || c == '/' )    //   if any of the four operators are encountered, add it to the Stack
			{
				Stack[j] = c;
				j++;
			}
			else if( c != '(' && c != ')' )   //  add the characters to the PostFix if the current character is NOT EQUAL to ')' and '(' 
			{
				PostFix = PostFix + c;
			}
			else if( c == ')' )           //  if ')' character is encountered, then pop all the items from the Stack and append to the PostFix variable.
			{
				while( j >= 0 )
				{
					if( Stack[j] != ' ' )
					{
						PostFix = PostFix + Stack[j];
						Stack[j] = ' ';
					}
					j--;
				}
				j=0;
			}
		}
		
		// *****   Just to be sure, pop the items from the Stack (if any) and append it to the PostFix variable.
		while( j >= 0 )
		{
			if( Stack[j] != ' ' )
			{
				PostFix = PostFix + Stack[j];
				Stack[j] = ' ';
			}
			j--;
		}
		
		System.out.println("InFix Expression is:" + InFix);
		System.out.println("");
		System.out.println("It's PostFix Expression is:" + PostFix);
	}
}