class Prac2_3
{
	public static void main(String arg[])
	{
		//String Expression = "B*-C+D*-C";  
		//String Expression = "-B*C+-B*D";   
		//String Expression = "-B*-C+-B*-C";
		String Expression = "-B*-C+-B*-D";
		
		int Exp_Length = Expression.length();
		String[] Exp_Array = new String[Exp_Length];
		String[][] Result = new String[20][6];
		String[] Operands = new String[2];
		
		char c=' ';
		char Operator = ' ';
		char Master_Operator = ' ';
		
		int T_Count=0;
		int i=0 , j=0 , k=0;
		int Operands_Index = 0;
		int Exp_Array_Count = 0;
		int Result_Count = 0;

		boolean IsPreviousLetterOperator = false;
		boolean OperandPendingToTemp = false;
		boolean IncrementResult_Count = false;
		
		Operands[0] = "";
		Operands[1] = "";
		
		for( i=0 ; i<Exp_Length ; i++ )
		{
			c = Expression.charAt(i);
			if( c=='+' || c=='-' || c=='*' || c=='/' )
			{
				if( c=='-' && ( i==0 || IsPreviousLetterOperator == true ) )
				{
					Operands[Operands_Index] = c +"";
					i++;
					c = Expression.charAt(i);
					Operands[Operands_Index] = Operands[Operands_Index] + c;
					IsPreviousLetterOperator = false;
					Exp_Array[Exp_Array_Count] = Operands[Operands_Index];
					Exp_Array_Count++;
					Operands_Index++;
				}
				else if( i>0 )
				{
					if( Operands[0].equals("")==false && Operands[1].equals("")==true )
					{
						Operator = c;
						IsPreviousLetterOperator = true;
						Exp_Array[Exp_Array_Count] = Operator +"";
						Exp_Array_Count++;
					}
					else if( Operands[0].equals("")==true && Operands[1].equals("")==true && Master_Operator==' ' )
					{
						Master_Operator = c;
						IsPreviousLetterOperator = true;
						Exp_Array[Exp_Array_Count] = Master_Operator +"";
						Exp_Array_Count++;
					}
				}
			}
			else
			{
				Operands[Operands_Index] = c +"";
				IsPreviousLetterOperator = false;
				Exp_Array[Exp_Array_Count] = Operands[Operands_Index];
				Exp_Array_Count++;
				Operands_Index++;
			}
			
			if(Operands_Index == 2)
			{
				if( Operands[0].length()>1 && Operands[0].indexOf("-")>=0 && Operands[1].length()>1 && Operands[1].indexOf("-")>=0 )
				{
					if( Result_Count == 0 )
					{
						Result[Result_Count][0] = "T1";
						Result[Result_Count][1] = Operands[0];
						Result[Result_Count][2] = Operands[0];
						Result[Result_Count][3] = Operator +"";
						Result[Result_Count][4] = Operands[1];
						Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						Result_Count++;
						Result[Result_Count][0] = "T2";
						Result[Result_Count][1] = Operands[1];
						Result[Result_Count][2] = Operands[0];
						Result[Result_Count][3] = Operator +"";
						Result[Result_Count][4] = Operands[1];
						Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						Result_Count++;
						Result[Result_Count][0] = "T3";
						Result[Result_Count][1] = "=";
						Result[Result_Count][2] = "T1";
						Result[Result_Count][3] = Operator +"";
						Result[Result_Count][4] = "T2";
						Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						Result_Count++;
					}
					else
					{
						boolean IsMatchFound=false;
						for( j=0 ; j<Result_Count ; j++ )
						{
							if( Result[j][1].equals("=") && Result[j][5].equals(Operands[0]+Operator+Operands[1]) )
							{
								Result[Result_Count][0] = "T4";
								Result[Result_Count][1] = "=";
								Result[Result_Count][2] = Result[j][0];
								Result[Result_Count][3] = Master_Operator +"";
								Result[Result_Count][4] = Result[j][0];
								Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
								IsMatchFound=true;
								break;
							}
						}
						String Get_T_Op1 = "";
						String Get_T_Op2 = "";
						if( !IsMatchFound )
						{
							for( j=0 ; j<Result_Count ; j++ )
							{
								if( Result[j][1].equals(Operands[0]) )
								{
									Get_T_Op1 = Result[j][0];
								}
								else if( Result[j][1].equals(Operands[1]) )
								{
									Get_T_Op2 = Result[j][0];
								}
							}
							Result[Result_Count][0] = "T4";
							if( Get_T_Op1.equals("") )
							{
								Result[Result_Count][1] = Operands[0];
							}
							
							if( Get_T_Op2.equals("") )
							{
								Result[Result_Count][1] = Operands[1];
							}
							Result[Result_Count][2] = Operands[0];
							Result[Result_Count][3] = Operator +"";
							Result[Result_Count][4] = Operands[1];
							Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
							Result_Count++;
							Result[Result_Count][0] = "T5";
							Result[Result_Count][1] = "=";
							if( Get_T_Op1.equals("")==false )
							{
								Result[Result_Count][2] = Get_T_Op1;
								Result[Result_Count][4] = "T4";
							}
							if( Get_T_Op2.equals("")==false )
							{
								Result[Result_Count][2] = "T4";
								Result[Result_Count][4] = Get_T_Op2;
							}
							Result[Result_Count][3] = Operator +"";
							
							Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
							Result_Count++;
							Result[Result_Count][0] = "T6";
							Result[Result_Count][1] = "=";
							Result[Result_Count][2] = "T3";
							Result[Result_Count][3] = Master_Operator +"";
							Result[Result_Count][4] = "T5";
							Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						}
					}
				}
				
				
				if( Operands[0].length()>1 && Operands[0].indexOf("-")>=0 && Operands[1].length()==1 && Operands[1].indexOf("-")==-1 )
				{
					if( Result_Count == 0 )
					{
						Result[Result_Count][0] = "T1";
						Result[Result_Count][1] = Operands[0];
						Result[Result_Count][2] = Operands[0];
						Result[Result_Count][3] = Operator +"";
						Result[Result_Count][4] = Operands[1];
						Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						Result_Count++;
						Result[Result_Count][0] = "T2";
						Result[Result_Count][1] = "=";
						Result[Result_Count][2] = "T1";
						Result[Result_Count][3] = Operator +"";
						Result[Result_Count][4] = Operands[1];
						Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						Result_Count++;
					}
					else
					{
						boolean IsMatchFound=false;
						for( j=0; j<Result_Count; j++ )
						{
							if( Result[j][1].equals("=") && Result[j][5].equals( Operands[0]+Operator+Operands[1] ) )
							{
								Result[Result_Count][0] = "T3";
								Result[Result_Count][1] = "=";
								Result[Result_Count][2] = Result[j][0];
								Result[Result_Count][3] = Master_Operator +"";
								Result[Result_Count][4] = Result[j][0];
								Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
								IsMatchFound=true;
								break;
							}
						}
						String Get_T_Op1 = "";
						String Get_T_Op2 = "";
						if( !IsMatchFound )
						{
							for( j=0 ; j<Result_Count ; j++ )
							{
								if( Result[j][1].equals(Operands[0]) )
								{
									Get_T_Op1 = Result[j][0];
								}
								else if( Result[j][1].equals(Operands[1]) )
								{
									Get_T_Op2 = Result[j][0];
								}
							}
							Result[Result_Count][0] = "T3";
							Result[Result_Count][1] = "=";
							if( Get_T_Op1.equals("")==false )
							{
								Result[Result_Count][2] = Get_T_Op1;
								Result[Result_Count][4] = Operands[1];
							}
							if( Get_T_Op2.equals("")==false )
							{
								Result[Result_Count][2] = Operands[0];
								Result[Result_Count][4] = Get_T_Op2;
							}
							Result[Result_Count][3] = Operator +"";							
							Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
							Result_Count++;
							
							Get_T_Op1="";
							Get_T_Op2="";
							for( j=0; j<Result_Count; j++ )
							{
								if( Result[j][1].equals("=") )
								{
									if( Get_T_Op1.equals("") )
									{
										Get_T_Op1 = Result[j][0];
									}
									else
									{
										Get_T_Op2 = Result[j][0];
									}
								}
							}
							Result[Result_Count][0] = "T4";
							Result[Result_Count][1] = "=";
							Result[Result_Count][2] = Get_T_Op1;
							Result[Result_Count][3] = Master_Operator +"";
							Result[Result_Count][4] = Get_T_Op2;
							Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						}
					}
				}
				
				if( Operands[0].length()==1 && Operands[0].indexOf("-")==-1 && Operands[1].length()>1 && Operands[1].indexOf("-")>=0 )
				{
					if( Result_Count == 0 )
					{
						Result[Result_Count][0] = "T1";
						Result[Result_Count][1] = Operands[1];
						Result[Result_Count][2] = Operands[0];
						Result[Result_Count][3] = Operator +"";
						Result[Result_Count][4] = Operands[1];
						Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						Result_Count++;
						Result[Result_Count][0] = "T2";
						Result[Result_Count][1] = "=";
						Result[Result_Count][2] = Operands[0];
						Result[Result_Count][3] = Operator +"";
						Result[Result_Count][4] = "T1";
						Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						Result_Count++;
					}
					else
					{
						boolean IsMatchFound=false;
						for( j=0; j<Result_Count; j++ )
						{
							if( Result[j][1].equals("=") && Result[j][5].equals( Operands[0]+Operator+Operands[1] ) )
							{
								Result[Result_Count][0] = "T3";
								Result[Result_Count][1] = "=";
								Result[Result_Count][2] = Result[j][0];
								Result[Result_Count][3] = Master_Operator +"";
								Result[Result_Count][4] = Result[j][0];
								Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
								IsMatchFound=true;
								break;
							}
						}
						String Get_T_Op1 = "";
						String Get_T_Op2 = "";
						if( !IsMatchFound )
						{
							for( j=0 ; j<Result_Count ; j++ )
							{
								if( Result[j][1].equals(Operands[0]) )
								{
									Get_T_Op1 = Result[j][0];
								}
								else if( Result[j][1].equals(Operands[1]) )
								{
									Get_T_Op2 = Result[j][0];
								}
							}
							Result[Result_Count][0] = "T3";
							Result[Result_Count][1] = "=";
							if( Get_T_Op1.equals("")==false )
							{
								Result[Result_Count][2] = Get_T_Op1;
								Result[Result_Count][4] = Operands[1];
							}
							if( Get_T_Op2.equals("")==false )
							{
								Result[Result_Count][2] = Operands[0];
								Result[Result_Count][4] = Get_T_Op2;
							}
							Result[Result_Count][3] = Operator +"";							
							Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
							Result_Count++;
							
							Get_T_Op1="";
							Get_T_Op2="";
							for( j=0; j<Result_Count; j++ )
							{
								if( Result[j][1].equals("=") )
								{
									if( Get_T_Op1.equals("") )
									{
										Get_T_Op1 = Result[j][0];
									}
									else
									{
										Get_T_Op2 = Result[j][0];
									}
								}
							}
							Result[Result_Count][0] = "T4";
							Result[Result_Count][1] = "=";
							Result[Result_Count][2] = Get_T_Op1;
							Result[Result_Count][3] = Master_Operator +"";
							Result[Result_Count][4] = Get_T_Op2;
							Result[Result_Count][5] = Operands[0]+Operator+Operands[1];
						}
					}
				}
				
				Operands[0] = "";
				Operands[1] = "";
				Operands_Index = 0;
			}
		}
		
		
		
		System.out.println("\nThe Expression is: "+ Expression +"\n");
		
		//System.out.println("The Result_Count is:"+ Result_Count);
		
		System.out.println("The THREE ADDRESS CODE table is:\n");
		for( i=0 ; i<Result_Count+1 ; i++)
		{
			for( j=0 ; j<6 ; j++ )
			{
				if( j!=1 && j!=5 )
				{
					System.out.print( Result[i][j] +"\t" );
				}
			}
			System.out.println("");
		}
	}
}