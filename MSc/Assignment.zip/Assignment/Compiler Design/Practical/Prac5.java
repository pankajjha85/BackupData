class Prac5
{
	public static void main(String args[])
	{
		String[][] Productions={
			{"Z","bMb"},
			{"M","a"},
			{"L","Ma)"},
			{"M","(L"},
		};
		String[][] SPM={
			{"", "b", "(", "a", ")", "Z", "M", "L"},
			{"b", "0", "<", "<", "0", "0", "=", "0"},
			{"(", "0", "<", "<", "0", "0", "<", "="},
			{"a", ">", "0", ">", "=", "0", "0", "0"},
			{")", ">", "0", ">", "0", "0", "0", "0"},
			{"Z", "0", "0", "0", "0", "0", "0", "0"},
			{"M", "=", "0", "=", "0", "0", "0", "0"},
			{"L", ">", "0", ">", "0", "0", "0", "0"}
		};
		
		String ToBeParsed = "#b((aa)a)b#";
		//String ToBeParsed = "#b(((aa)b#";
		//String ToBeParsed = "#b((a)a)a)b#";
		
		char[][] Result=new char[2][20];
		char First=' ' , Next=' ';
		
		int i=0 , j=0 , k=0 ;
		int SPM_i = 0, SPM_j = 0;
		int Productions_i = 0, Productions_j = 0;
		
		String StrTemp="";
		boolean StopSearch=false;
		
		System.out.println("The Original Expression is: "+ ToBeParsed);
		
		while(i<10)	//   ToBeParsed.length()>=3)
		{
			Result[0]=ToBeParsed.toCharArray();
			
			for( j=0 ; j<Result[0].length ; j++ )
			{
				First=Result[0][j];
				Next=Result[0][j+1];
				
				//System.out.println("First: "+ First);
				//System.out.println("Next: "+ Next);
				
				if( First=='#' )
				{
					Result[0+1][j] = '<';
				}
				else if( Next=='#' )
				{
					Result[0+1][j] = '>';
				}
				else if( First!=' ' && Next!=' ' )
				{
					for( SPM_i=1 ; SPM_i<8 ; SPM_i++ )
					{
						if( SPM[SPM_i][0].equals( First+"" ) )
						{
							for( SPM_j=1 ; SPM_j<8 ; SPM_j++ )
							{
								if( SPM[0][SPM_j].equals( Next+"" ) )
								{
									Result[0+1][j] = SPM[SPM_i][SPM_j].charAt(0);
									StopSearch=true;
									//System.out.println("SPM[SPM_i][SPM_j]: "+ SPM[SPM_i][SPM_j]);
									break;
								}
							}
							if( StopSearch )
							{
								StopSearch=false;
								break;
							}
						}
					}
				}
				
				
				if( Result[0+1][j]=='>' )
				{
					//System.out.println("Result[0+1][j]: "+ Result[0+1][j]);
					break;
				}
			}
			
			for( k=j ; k>=0 ; k-- )
			{
				StrTemp = Result[0][k] + StrTemp;
				//System.out.println("k: "+ k +"             StrTemp: "+ StrTemp +"           Result[0+1][k]: "+ Result[0+1][k]);
				if( Result[0+1][k-1]=='<' )
				{
					break;
				}
			}
			
			for( Productions_i=0 ; Productions_i<4 ; Productions_i++ )
			{
				if( Productions[Productions_i][1].equals(StrTemp) )
				{
					System.out.println("Handle found: "+ StrTemp);
					System.out.println("Replaced by: "+ Productions[Productions_i][0]);
					
					ToBeParsed = ToBeParsed.substring(0, k) + Productions[Productions_i][0] + ToBeParsed.substring(k+StrTemp.length());
					
					System.out.println("New Expression is: " +ToBeParsed);
					
					StrTemp = "";
					
					if( ToBeParsed.equals("#Z#") )
					{
						i=999;
						break;
					}
				}
			}
			StrTemp = "";
			if( ToBeParsed.equals("Z") )
			{
				break;
			}
			
			i++;
		}
		
		if( ToBeParsed.equals("#Z#") )
		{
			System.out.println("The given Expression is Parsable");
		}
		else
		{
			System.out.println("The given Expression is Not Parsable");
		}
		
		/*
		for( i=0; i<2 ; i++ )
		{
			for( j=0; j<20 ; j++ )
			{
				try
				{
					System.out.print(Result[i][j] +"   ");
				}
				catch(Exception ex)
				{
					break;
				}
			}
			System.out.println("");
		}
		*/
	}
}
