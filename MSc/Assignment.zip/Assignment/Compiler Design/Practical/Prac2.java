class Prac2
{
	public static void main(String args[])
	{
		String[][] Productions = {
			{"S","b","C"},
			{"B","e","D"},
			{"D","a","C"},
			{"D"," ","C"}
		};
		
		char temp = (char)Productions[0][0].charAt(0);
		int i=0 , j=0 ;
		
		char[] Terminals = new char[4];
		char[] NonTerminals = new char[12];
		
		String StrTemp="";
		
		boolean IsRightLinearGrammar=true;
		
		for( i=0 ; i<4 ; i++ )
		{
			temp = (char)Productions[i][1].charAt(0);
			
			if( ((int)temp >= 97 && (int)temp<=122) || temp==' ' )
			{
				if( StrTemp.indexOf(temp)==-1 )
				{
					StrTemp = StrTemp+temp;
					Terminals[i] = temp;
				}
			}
			else
			{
				IsRightLinearGrammar=false;
				break;
			}
		}
		
		if( IsRightLinearGrammar )
		{
			StrTemp="";
			j=0;
			for( i=0 ; i<4 ; i++ )
			{
				temp = (char)Productions[i][0].charAt(0);
				if( (int)temp >= 65 && (int)temp<=90 )
				{
					if( StrTemp.indexOf(temp)==-1 )
					{
						StrTemp = StrTemp+temp;
						NonTerminals[j] = temp;
						j++;
					}
				}
				else
				{
					IsRightLinearGrammar = false;
					break;
				}
				
				temp = (char)Productions[i][2].charAt(0);
				if( (int)temp >= 65 && (int)temp<=90 )
				{
					if( StrTemp.indexOf(temp)==-1 )
					{
						StrTemp = StrTemp+temp;
						NonTerminals[j] = temp;
						j++;
					}
				}
				else
				{
					IsRightLinearGrammar = false;
					break;
				}
			}
			
			if( IsRightLinearGrammar )
			{
				//*** Print Original Productions ***
				System.out.println("\nThe Initial Productions (Right Linear Grammar) are:");
				for( i=0 ; i<4 ; i++ )
				{
					for( j=0 ; j<3 ; j++ )
					{
						if( j==1 )
						{
							System.out.print("->");
						}
						System.out.print(Productions[i][j]);
					}
					System.out.println("");
				}
				
				//*** Start converting Right Linear Grammar to Left Linear Grammar
				
				//********* First swap the values in Productions array between the positions 2nd and 3rd.
				for( i=0 ; i<4 ; i++ )
				{
					StrTemp = Productions[i][2];
					Productions[i][2] = Productions[i][1];
					Productions[i][1] = StrTemp;
				}
				
				//********* Now swap the values in Productions array between the positions 1st and 2nd.
				for( i=0 ; i<4 ; i++ )
				{
					StrTemp = Productions[i][1];
					Productions[i][1] = Productions[i][0];
					Productions[i][0] = StrTemp;
				}
				
				
				//*** Print Terminals ****
				System.out.print("\nThe Terminals are:");
				for( i=0 ; i<4 ; i++ )
				{
					System.out.print(Terminals[i] +" ");
				}
				System.out.println("\n");
				
				//*** Print NonTerminals ****
				System.out.print("\nThe NonTerminals are:");
				for( i=0 ; i<12 ; i++ )
				{
					System.out.print(NonTerminals[i] +" ");
				}
				System.out.println("\n");
				
				//*** Print Productions ***
				System.out.println("\nThe updated Productions (Left Linear Grammar) are:");
				for( i=0 ; i<4 ; i++ )
				{
					for( j=0 ; j<3 ; j++ )
					{
						if( j==1 )
						{
							System.out.print("->");
						}
						System.out.print(Productions[i][j]);
					}
					System.out.println("");
				}
				
				
			}
			else
			{
				System.out.println("The Productions are not in Right Linear Grammar form, hence cannot process it further.");
			}
		}
		else
		{
			System.out.println("The Productions are not in Right Linear Grammar form, hence cannot process it further.");
		}
	}
}