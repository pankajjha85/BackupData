import java.io.*;

public class Test{
   public static void main(String args[]){
      String testString = "This is a test string";

	  // Start index, End index
	  System.out.print("Test 1: ");
	  System.out.println(testString.substring(0, 4));
	  
	  // Start index, End index
	  System.out.print("Test 2: ");
      System.out.println(testString.substring(4, 6) );
	  
	  // Start index to the end
	  System.out.print("Test 3: ");
      System.out.println(testString.substring(7) );
   }
}