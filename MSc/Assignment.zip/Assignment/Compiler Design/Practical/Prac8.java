class Prac8
{
    public static void main(String a[])
    {
        // X -> @X + B
        String arden_equation = "X=@X+B";

        // X -> @* B
        String arden_soln = "X=@*B";

        String non_terminal_at_lhs = arden_equation.substring(0, 1);
        int lhs_non_terminal_index_in_rhs = arden_equation.lastIndexOf(non_terminal_at_lhs);
        String alpha = "@";
        int alpha_index = arden_equation.indexOf(alpha);
        String betaa = "B";
        int betaa_index = arden_equation.indexOf(betaa);

        String non_terminal_at_lhs_in_result = "";
        String non_terminal_after_alpha_in_result = "";
        String alpha_in_result = "";
        String betaa_in_result = "";
        String String_to_be_replaced = "";

        String prod[][] = { { "S=0S+0A" }, { "A=1A+1B" }, { "B=0B+L" } };

        String reg_exp[][] = new String[3][1];

        reg_exp = prod;

        String grammar;

        for (int i = 2; i >= 0; i--)
        {
            grammar = reg_exp[i][0];

            if (!non_terminal_at_lhs_in_result.equals(""))
            {
                grammar = grammar.replace(non_terminal_at_lhs_in_result, String_to_be_replaced);
            }

            non_terminal_at_lhs_in_result = grammar.substring(0, 1);
            non_terminal_after_alpha_in_result = grammar.substring(grammar.lastIndexOf(non_terminal_at_lhs_in_result), grammar.lastIndexOf(non_terminal_at_lhs_in_result)+1);

            int plus_index_in_arden = arden_equation.indexOf('+');
            int plus_index_in_grammar = grammar.indexOf('+');

            int assignment_index_in_arden = arden_equation.indexOf('=');
            int assignment_index_in_grammar = grammar.indexOf('=');

            if (assignment_index_in_arden == assignment_index_in_grammar && plus_index_in_arden == plus_index_in_grammar)
            {
                if (non_terminal_at_lhs_in_result.equals(non_terminal_after_alpha_in_result))
                {
                    // PRINT " the grammer satisfies Arden's theorem "
                    alpha_in_result = grammar.substring(alpha_index, alpha_index+1);
                    betaa_in_result = grammar.substring(betaa_index, betaa_index+(grammar.length() - betaa_index));

                    if (betaa_in_result.equals("L"))
                    {
                        betaa_in_result = "";  // check if betaa = lambda, then ignore it.
                    }

                    grammar = non_terminal_at_lhs_in_result + "=" + alpha_in_result + "*" + betaa_in_result;
                    String_to_be_replaced = alpha_in_result + "*" + betaa_in_result;

                    reg_exp[i][0] = grammar;

		    System.out.println("The equation of Non-Terminal "+ non_terminal_at_lhs_in_result +" is:");
		    System.out.println(grammar);
		    System.out.println("The string to be replaced are "+ String_to_be_replaced);
                }

            }
        }
    }
}
