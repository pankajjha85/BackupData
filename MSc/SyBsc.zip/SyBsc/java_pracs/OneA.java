public class OneA
{
	public static void main(String args[])
	{
		// **** Downcasting the object
		Object obj = "This is a String downcasted from an Object";
		String str_obj = (String)obj;
		System.out.println("Downcasting from an Object to String: "+ str_obj);
		
		// **** Upcasting the object
		str_obj = "This is a String upcasted to an Object";
		obj = (Object)str_obj;
		
		int i=1;
		obj=(Object)(""+i);
		// **** Upcasting ends here
		
		// **** Cast String to an Integer
		str_obj="100";
		i=Integer.parseInt(str_obj);
		System.out.println("String has been casted to an Integer: "+i);
		
		float f=(float)i;
		System.out.println("An Integer has been casted to a Float: "+f);
		
		double d=(double)i;
		System.out.println("An Integer has been casted to a Double: "+d);
		
		
		
		// **** TRY THIS : 
		// convert boolean to String and print
		boolean b=true;
		
		// **** TRY THIS :
		// convert double to an Integer
		d=100.0;
		
	}
}