public class TwoC
{
	public static void main(String args[])
	{
		// *** convert char array to String
		char ch[]={'s','t','r','i','n','g','s'};
		String s=new String(ch);
		
		// *** concat Strings
		s=s.concat(" some more characters");
		
		// *** find a position of a character from the beginning
		int index = s.indexOf('t');
		
		// *** TRY THIS:
		// find the position of a character from an end of the String
		
		// *** get a part of String
		String s1 = s.substring(0,2);
		System.out.println(s1);
		
		// *** replace one or more characters in a String
		s1=s.replace('s','x');
		System.out.println(s1);
		
		// *** compare two Strings
		s="THIS IS JAVA";
		s1="this is java";
		System.out.println(s.equals(s1));
		
		// *** TRY THIS:
		// compare the above two Strings by ignoring their case sensitivity
		
		// *** TRY THIS:
		// split the below String by comma as a delimiter and print the result
		s="1,2,3,4,5";

		// *** TRY THIS:
		// find the length of the above String
		
	}
}