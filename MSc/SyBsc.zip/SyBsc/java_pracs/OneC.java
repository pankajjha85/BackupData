public class OneC
{
	public static void main(String args[])
	{
		int result=OneC.add(10,20);
		result=OneC.add(10,20,30);
		
		HDFC hdfc=new HDFC();
		int ROI=hdfc.ROI();
		System.out.println("HDFC ROI is: "+ROI);
		
		SBI sbi=new SBI();
		ROI=sbi.ROI();
		System.out.println("SBI ROI is: "+ROI);
	}
	// Same data-type, different number of parameters
	static int add(int a, int b)
	{
		return a+b;
	}
	static int add(int a, int b, int c)
	{
		return a+b+c;
	}
	
	// different data-type, same number of parameters
	static double add(double a, double b)
	{
		return a+b;
	}
	
	static void add(int a, double b)
	{
		System.out.println(a+b);
	}
}

class Bank
{
	int ROI()
	{
		return 0;
	}
}
class HDFC extends Bank
{
	int ROI()
	{
		return 8;
	}
}
class SBI extends Bank
{
	int ROI()
	{
		return 7;
	}
}