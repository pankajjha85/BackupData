public class TwoB
{
	public static void main(String args[])
	{
		iShapes s=new ShapeRect();
		s.draw();
		
		s=new ShapeCircle();
		s.draw();
		
		// *** TRY THIS:
		// check if Interface can extend an another Interface
	}
}

interface iShapes
{
	void draw();
}

class ShapeRect implements iShapes
{
	public void draw()
	{
		System.out.println("Drawing Rectangle now.");
	}
}

class ShapeCircle implements iShapes
{
	public void draw()
	{
		System.out.println("Drawing Circle now.");
	}
}