public class TwoA
{
	public static void main(String args[])
	{
		Mobile m = new Mobile();
		m.activateData();
		m.activateVoice();
		
		Bike b = new Bike();
		b.startType();
		b.fuelType();
	}
}

interface iData
{
	void activateData();
}

interface iVoice
{
	void activateVoice();
}

// *** Multiple Inheritance
class Mobile implements iData, iVoice
{
	public void activateData()
	{
		System.out.println("Data has been activated");
	}
	
	public void activateVoice()
	{
		System.out.println("Voice has been activated");
	}
}

// Multi-level Inheritance
abstract class Vehicle
{
	abstract void fuelType();
}
class TwoWheeler extends Vehicle
{
	public void fuelType()
	{
		System.out.println("Fuel Type in Two Wheeler is Petrol");
	}
	public void startType()
	{	}
}
class Bike extends TwoWheeler
{
	public void startType()
	{
		System.out.println("Start type is SELF");
	}
}