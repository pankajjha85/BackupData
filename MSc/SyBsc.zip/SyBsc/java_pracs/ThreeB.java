public class ThreeB
{
	public static void main(String args[])
	{
		int[][] m1={ {5,2,4} , {7,5,1} , {9,5,4} };
		int[][] m2={ {6,5,2} , {4,8,5} , {2,5,8} };
		
		int[][] m3=new int[3][3];
		int[][] m4=new int[3][3];
		
		int r=0, c=0, k=0, sum=0;
		
		// perform Addition of 2 matrix
		for(r=0; r<3; r++)
		{
			for(c=0; c<3; c++)
			{
				m3[r][c] = m1[r][c] + m2[r][c];
			}
		}
		
		System.out.println("m1 is:");
		for(r=0; r<3; r++)
		{
			for(c=0; c<3; c++)
			{
				System.out.print(m1[r][c] +"    ");
			}
			System.out.println();
		}
		
		System.out.println("m2 is:");
		for(r=0; r<3; r++)
		{
			for(c=0; c<3; c++)
			{
				System.out.print(m2[r][c] +"    ");
			}
			System.out.println();
		}
		
		System.out.println("Addition is:");
		for(r=0; r<3; r++)
		{
			for(c=0; c<3; c++)
			{
				System.out.print(m3[r][c] +"    ");
			}
			System.out.println();
		}
		
		for(r=0; r<3; r++)
		{
			for(c=0; c<3; c++)
			{
				for(k=0; k<3; k++)
				{
					sum = sum + ( m1[r][k] * m2[k][c] );
					m4[r][c] = sum;
				}
				sum=0;
			}
		}
		
		System.out.println("Multiplication is:");
		for(r=0; r<3; r++)
		{
			for(c=0; c<3; c++)
			{
				System.out.print(m4[r][c] +"    ");
			}
			System.out.println();
		}
		
		// TRY THIS:
		// transpose can be done by interchanging the position of rows and columns
	}
}