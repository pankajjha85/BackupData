import java.io.*;
public class OneB
{
	public static void main(String args[]) throws IOException
	{
		// This class is used to get the input from the user.
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		// print the message
		System.out.println("Enter 1st Operand:");
		
		// declare and initialise a variable to validate if operand1 is valid.
		boolean isOperand1Valid=true;
		
		// initialise to a default value
		double operand1=0;
		try
		{
			// read the input from the user
			operand1 = Double.parseDouble(br.readLine());
		}
		catch(NumberFormatException NFE)	// catch the exception if alphabet is entered by the user instead of number
		{
			System.out.println("Invalid input. Program terminated.");
			
			// set false to this variable so that program does not proceed further
			isOperand1Valid=false;
		}
		
		// validate if operand1 was valid
		if(isOperand1Valid)
		{
			// print a message for user
			System.out.println("Enter 2nd Operand:");
			
			// declare and initialise a variable to validate if operand2 is valid.
			boolean isOperand2Valid=true;
			
			// initialise to a default value
			double operand2 = 0;
			try
			{
				// read the input from the user
				operand2 = Double.parseDouble(br.readLine());
			}
			catch(NumberFormatException NFE)	// catch the exception if alphabet is entered by the user instead of number
			{
				System.out.println("Invalid input. Program terminated.");
				
				// set false to this variable so that program does not proceed further
				isOperand2Valid=false;
			}
			
			// validate if operand2 was valid
			if(isOperand2Valid)
			{
				// print the message
				System.out.println("Enter the calculation you want to perform (+ , - , X , /):");
				
				// read the user input
				String operator = br.readLine();
				
				// validate if entered input is from either of these (+ , - , X , /), else terminate the program
				if(operator.equals("+")==false && operator.equals("-")==false && operator.equalsIgnoreCase("x")==false && operator.equals("/")==false)
				{
					System.out.println("Invalid input. Program terminated.");
				}
				else
				{
					// initialise the object of the current class.
					OneB thisClass = new OneB();
					
					// call the calculate method of this class and store the result.
					double result = thisClass.calculate(operand1,operator,operand2);
					
					// print the message
					System.out.println("The result is:");
					
					// print the output
					System.out.println(result);
				}
			}
			
		}
		
		
	}
	
	public double calculate(double operand1, String operator, double operand2)
	{
		// initialise with default value
		double result=0;
		
		// check the operator value and perform the calculation accordingly
		if(operator.equals("+"))
		{
			result = operand1 + operand2;
		}
		else if(operator.equals("-"))
		{
			result = operand1 - operand2;
		}
		else if(operator.equalsIgnoreCase("x"))
		{
			result = operand1 * operand2;
		}
		else if(operator.equals("/"))
		{
			// for division, check if operand2 is zero, then set to 1.
			if(operand2==0)
			{
				operand2=1;
			}
			result = operand1 / operand2;
		}
		return result;
	}
}