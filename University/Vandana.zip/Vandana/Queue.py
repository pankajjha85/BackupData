que = []

# store any default value in the user-input variable
user_choice = 0

# iterate till user indicates that he/she wants to exit the program.
# to exit the program, we will expect user to input 3 else the program will keep running.
while(True):
    user_choice = int(input('Enter your choice, 1 for Enqueue, 2 for Dequeue and 3 to Exit the program.'))
    
    # exit this while loop if user inputs 3.
    if user_choice == 3:
        print('You selected to Exit the program. Application terminated.')
        break
    elif user_choice == 1:    # if user selects to Enqueue any number.
        user_input = int(input('Enter any Number to Enqueue.'))
        que.append(user_input)
    elif user_choice == 2:    # if user selects to Dequeue.
        if len(que) == 0:
            print('No more elements to Dequeue.')
        else:
            que.remove(que[0])
            print('Dequeue successful.')
    
    print('The latest Queue : ')
    print(que)