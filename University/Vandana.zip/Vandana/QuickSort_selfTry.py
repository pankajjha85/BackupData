l = [54,26,93,17,77,31,44,55,20]
pivot_index = 0
left = 1
right = len(l)-1

l = QuickSort(l , pivot_index , left , right)

l = QuickSort(l , 0 , 1 , (5-1))

l = QuickSort(l , 0 , 1 , (3-1))

def QuickSort(prm_list , prm_pivot_index , prm_left , prm_right):
#{
    pivot = prm_list[prm_pivot_index]
    while(True):
    #{
        while(True):
        #{
            try:
                if prm_list[prm_left] <= pivot and prm_left <= prm_right :
                    #print('prm_left=',prm_left)
                    #print('prm_list',prm_list)
                    prm_left = prm_left + 1
                else:
                    break
            except:
                break
        #}
        
        while(True):
        #{
            try:
                if prm_list[prm_right] >= pivot and prm_right >= prm_left:
                    #print('prm_right=',prm_right)
                    prm_right = prm_right - 1
                else:
                    break
            except:
                break
        #}
        
        if prm_right < prm_left:
            temp = prm_list[prm_right]
            prm_list[prm_right] = prm_list[prm_pivot_index]
            prm_list[prm_pivot_index] = temp
            
            print('prm_left',prm_left,'prm_right',prm_right)
            
            #QuickSort(prm_list[0:prm_right] , 0 , 1, prm_right)
            #QuickSort(prm_list[prm_right:len(prm_list)] , prm_left , (prm_left+1), len(prm_list)-1)
            break
        
        temp = prm_list[prm_left]
        prm_list[prm_left] = prm_list[prm_right]
        prm_list[prm_right] = temp
    #}
    return prm_list
#}